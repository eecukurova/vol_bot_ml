"""Volensy LLM Futures - Transformer-based 0.5% TP scalper."""

__version__ = "0.1.0"
