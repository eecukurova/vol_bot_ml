# 🧪 Volensy NASDAQ Screener v1.1 - Smoke Test Guide

## ✅ Prerequisites

```bash
cd ~/ATR/NASDAQ
python3 -c "import pandas, numpy, yfinance; print('Dependencies OK')"
```

**Expected**: ✅ Dependencies OK

---

## 🧪 Test 1: Fetch Data

```bash
python3 -m src.volensy.cli fetch --start 2024-06-01 --end 2025-01-01
```

**Expected Output**:
- ✅ "Fetched data for N symbols"
- ✅ `cache/` directory has data files
- ✅ Log messages: "min_bars >= 120" validation

**Verification**:
```bash
ls -lh cache/ | head -5
```

---

## 🧪 Test 2: Screen Stocks

```bash
python3 -m src.volensy.cli screen --top 15 --include-explanations --export csv,html
```

**Expected Output**:
- ✅ Table with top 15 stocks
- ✅ Columns visible: symbol, score, close, signals, age
- ✅ "Exported to: outputs/screen_*.csv" and "outputs/screen_*.html"

**Verification**:
```bash
# Check CSV columns
head -1 outputs/screen_*.csv

# Expected columns:
# symbol,score,close,volume,technical_score,momentum_score,volume_score,fired_signals,explanations,last_signal_age,score_breakdown

# Check if HTML exists
ls -lh outputs/screen_*.html
```

**Check CSV for v1.1 columns**:
```bash
cat outputs/screen_*.csv | head -3
```

**Expected**: Columns like `fired_signals`, `explanations`, `last_signal_age`, `score_breakdown`

---

## 🧪 Test 3: Backtest

```bash
python3 -m src.volensy.cli backtest \
  --lookback-days 180 \
  --slippage-bps 7 \
  --commission-bps 5 \
  --position-sizing fixed_cash \
  --fixed-cash-usd 100
```

**Expected Output**:
- ✅ Table with backtest metrics
- ✅ "Metrics written to: outputs/metrics.json"

**Verification**:
```bash
# Check metrics.json exists and has content
cat outputs/metrics.json | head -20

# Expected structure:
# {
#   "metrics": {
#     "CAGR": <number>,
#     "Volatility": <number>,
#     "Sharpe": <number>,
#     "Sortino": <number>,
#     "MaxDrawdown": <number>,
#     "WinRate": <number>,
#     "Expectancy": <number>
#   },
#   "total_trades": <number>,
#   "config": {...}
# }
```

---

## 📊 HTML Check

Open `outputs/screen_*.html` in browser and verify:

✅ **Color Coding**:
- Green rows (score ≥ 80)
- Yellow rows (40 ≤ score < 80)
- Red rows (score < 40)

✅ **Tooltips**: Hover over cells to see explanations and breakdown

✅ **Summary Section**: Shows total symbols, average score, top signals

---

## 🎯 Acceptance Criteria

### CSV Output ✅
- [ ] Contains `fired_signals` column (JSON array)
- [ ] Contains `explanations` column (string)
- [ ] Contains `last_signal_age` column (number)
- [ ] Contains `score_breakdown` column (JSON string)

### HTML Output ✅
- [ ] Conditional formatting by score
- [ ] Tooltips on hover
- [ ] Summary metrics at top

### metrics.json ✅
- [ ] Contains: CAGR, Volatility, Sharpe, Sortino, MaxDrawdown, WinRate, Expectancy
- [ ] No NaN values (if data sufficient)
- [ ] Config section included

---

## 🐛 Troubleshooting

### Import Errors
```bash
# Check if all modules import correctly
python3 -c "from src.volensy import config; print('✅ Config OK')"
python3 -c "from src.volensy import signals; print('✅ Signals OK')"
python3 -c "from src.volensy import screen; print('✅ Screen OK')"
```

### Data Issues
- Check `symbols.csv` exists: `ls src/volensy/data/symbols.csv`
- Check internet connection for yfinance
- Check log files: `tail -f logs/volensy.log`

### Empty Results
- Ensure date range has market data
- Check if symbols are valid NASDAQ symbols
- Verify min_bars requirement (120)

---

## 🎉 Success Criteria

✅ All 3 commands complete without errors
✅ CSV has v1.1 columns
✅ HTML has conditional formatting
✅ metrics.json has all expected metrics
✅ No NaN in critical metrics

**Status**: Ready for production use! 🚀

