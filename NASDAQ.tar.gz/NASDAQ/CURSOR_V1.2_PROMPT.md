# Cursor Prompt - Volensy NASDAQ Screener v1.2

# Volensy NASDAQ Screener v1.2 — Local Run + Positions + ML Seed (DB-free)

GOALS:
1) Local-only persistence (no DB): storage/ altında parquet/csv/json
2) Paper trading run: orders/trades/positions/equity takibi
3) Signal logging: signals.parquet'e append
4) ML dataset üretimi (features + forward returns + threshold labels)

CONSTRAINTS:
- v1.1 mimarisini bozma; tüm yeni özellikler opsiyonel/flag'li
- Supabase/DB ekleme yok
- Existing modules remain unchanged

---

## 1. CONFIG (src/volensy/config.py)

Add new config section at the end:

```python
class StorageConfig(BaseModel):
    """Storage configuration for v1.2."""
    root: Path = Path("storage")
    signals_path: str = "storage/signals.parquet"
    orders_path: str = "storage/orders.parquet"
    trades_path: str = "storage/trades.parquet"
    positions_path: str = "storage/positions.json"
    equity_path: str = "storage/equity.csv"
    datasets_dir: str = "storage/datasets"
    rotation_max_mb: int = 256
    rotation_keep: int = 3

# In Config class, add:
storage: StorageConfig = Field(default_factory=StorageConfig)
```

---

## 2. UTILS (src/volensy/utils.py)

Add new functions at the end:

```python
import shutil
from pathlib import Path

def ensure_dirs(*paths):
    """Ensure directories exist."""
    for path in paths:
        Path(path).parent.mkdir(parents=True, exist_ok=True)

def rotate_if_big(filepath: Path, max_mb: int = 256, keep: int = 3):
    """Rotate file if it exceeds size limit."""
    if not filepath.exists():
        return
    
    size_mb = filepath.stat().st_size / (1024 * 1024)
    if size_mb > max_mb:
        for i in range(keep - 1, 0, -1):
            old = Path(f"{filepath}.{i}")
            new = Path(f"{filepath}.{i+1}")
            if old.exists():
                shutil.move(str(old), str(new))
        shutil.copy2(str(filepath), f"{filepath}.1")
        logger.info(f"Rotated {filepath}")

def safe_append_parquet(df: pd.DataFrame, path: Path):
    """Append DataFrame to Parquet file with rotation."""
    ensure_dirs(path)
    rotate_if_big(path, config.storage.rotation_max_mb, config.storage.rotation_keep)
    
    if path.exists():
        existing = pd.read_parquet(path)
        combined = pd.concat([existing, df], ignore_index=True)
    else:
        combined = df
    
    combined.to_parquet(path, index=False)

def safe_to_parquet(df: pd.DataFrame, path: Path, append: bool = False):
    """Write DataFrame to Parquet, optionally appending."""
    if append:
        safe_append_parquet(df, path)
    else:
        ensure_dirs(path)
        df.to_parquet(path, index=False)

def safe_write_json(obj: dict, path: Path):
    """Safely write JSON file."""
    ensure_dirs(path)
    with open(path, 'w') as f:
        json.dump(obj, f, indent=2, default=str)

def safe_read_json(path: Path, default: dict = None):
    """Safely read JSON file."""
    if path.exists():
        with open(path, 'r') as f:
            return json.load(f)
    return default or {}
```

---

## 3. SIGNAL LOGGING (src/volensy/screen/engine.py)

Add after ScreenEngine.screen() method (at the end of the class):

```python
def log_signals(self, data: Dict[str, pd.DataFrame], symbols: List[str]) -> None:
    """Log fired signals to storage/signals.parquet."""
    from ..utils import safe_append_parquet
    from ..config import config
    
    if not config.storage.signals_path:
        return
    
    signal_logs = []
    
    for symbol in symbols:
        if symbol not in data:
            continue
        
        df = data[symbol]
        if df.empty or len(df) < 120:
            continue
        
        try:
            # Get latest bar
            last_bar = df.iloc[-1]
            idx = df.index[-1]
            
            # Calculate indicators
            from ..indicators import calculate_rsi, calculate_ema, calculate_atr, calculate_donchian
            from ..indicators import calculate_52w_high_low
            
            rsi = calculate_rsi(df['close'], 14)
            ema50 = calculate_ema(df['close'], 50)
            ema200 = calculate_ema(df['close'], 200)
            atr = calculate_atr(df['high'], df['low'], df['close'], 14)
            up, _, down = calculate_donchian(df['high'], df['low'], 20)
            
            # Generate signals for logging
            signals = self._generate_signals(df)
            fired_now = {name: sig.fired.iloc[-1] if len(sig.fired) > 0 else False 
                         for name, sig in signals.items()}
            strength_map = {name: sig.strength for name, sig in signals.items()}
            
            explanations = _combine_explanations(signals)
            
            # Get score breakdown
            _, _, _, total, breakdown = compute_scores(df, fired_now, strength_map)
            
            fired_list = [name for name, fired in fired_now.items() if fired]
            
            signal_logs.append({
                'ts': idx,
                'symbol': symbol,
                'close': float(last_bar['close']),
                'rsi': float(rsi.iloc[-1]) if len(rsi) > 0 else None,
                'ema50': float(ema50.iloc[-1]) if len(ema50) > 0 else None,
                'ema200': float(ema200.iloc[-1]) if len(ema200) > 0 else None,
                'atr14': float(atr.iloc[-1]) if len(atr) > 0 else None,
                'donchian_h': float(up.iloc[-1]) if len(up) > 0 else None,
                'donchian_l': float(down.iloc[-1]) if len(down) > 0 else None,
                'fired_signals': json.dumps(fired_list),
                'explanations': explanations.iloc[-1] if len(explanations) > 0 else '',
                'score': float(total),
                'score_breakdown': json.dumps(breakdown)
            })
        
        except Exception as e:
            logger.error(f"Failed to log signal for {symbol}: {e}")
            continue
    
    if signal_logs:
        log_df = pd.DataFrame(signal_logs)
        safe_append_parquet(log_df, Path(config.storage.signals_path))
        logger.info(f"Logged {len(signal_logs)} signals")
```

---

## 4. EXECUTION LAYER (NEW: src/volensy/exec/)

Create new directory and files:

### exec/__init__.py
```python
"""Execution layer for paper trading (v1.2)."""

from .paper_broker import PaperBroker
from .position_tracker import PositionTracker
from .equity_curve import EquityCurve

__all__ = ["PaperBroker", "PositionTracker", "EquityCurve"]
```

### exec/paper_broker.py
```python
"""Paper broker for order/trade execution."""

import uuid
import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import Dict, List
from loguru import logger
from ..config import config
from ..utils import safe_to_parquet, safe_read_json, safe_write_json

class PaperBroker:
    """Simulates order execution with costs."""
    
    def __init__(self):
        self.orders_path = Path(config.storage.orders_path)
        self.trades_path = Path(config.storage.trades_path)
    
    def create_order(self, symbol: str, side: str, qty: int, price: float, reason: str) -> str:
        """Create and fill order immediately (market fill)."""
        order_id = str(uuid.uuid4())
        
        # Apply costs
        slippage = price * (config.bt.slippage_bps / 1e4)
        commission = price * (config.bt.commission_bps / 1e4)
        
        if side == "BUY":
            fill_price = price + slippage
        else:
            fill_price = price - slippage
        
        fill_price = fill_price + commission
        cost = qty * fill_price
        
        # Log order
        order_df = pd.DataFrame([{
            'ts': datetime.now(),
            'order_id': order_id,
            'symbol': symbol,
            'side': side,
            'qty': qty,
            'price': float(price),
            'fill_price': float(fill_price),
            'cost': float(cost),
            'slippage_bps': config.bt.slippage_bps,
            'commission_bps': config.bt.commission_bps,
            'reason': reason,
            'status': 'FILLED'
        }])
        
        safe_to_parquet(order_df, self.orders_path, append=True)
        
        # Log trade
        trade_df = pd.DataFrame([{
            'ts': datetime.now(),
            'trade_id': str(uuid.uuid4()),
            'order_id': order_id,
            'symbol': symbol,
            'side': side,
            'qty': qty,
            'price': float(fill_price),
            'pnl': None,
            'reason': reason
        }])
        
        safe_to_parquet(trade_df, self.trades_path, append=True)
        
        logger.info(f"Order {side} {qty} {symbol} @ ${fill_price:.2f} (reason: {reason})")
        
        return order_id
    
    def get_trades(self) -> pd.DataFrame:
        """Get all trades."""
        if self.trades_path.exists():
            return pd.read_parquet(self.trades_path)
        return pd.DataFrame()
    
    def get_orders(self) -> pd.DataFrame:
        """Get all orders."""
        if self.orders_path.exists():
            return pd.read_parquet(self.orders_path)
        return pd.DataFrame()
```

### exec/position_tracker.py
```python
"""Position tracker for open positions."""

import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional
from loguru import logger
from ..config import config
from ..utils import safe_read_json, safe_write_json

class PositionTracker:
    """Track open positions."""
    
    def __init__(self):
        self.positions_path = Path(config.storage.positions_path)
        self.positions = safe_read_json(self.positions_path, {})
    
    def apply_trade(self, trade: dict):
        """Apply trade to positions."""
        symbol = trade['symbol']
        side = trade['side']
        qty = trade['qty']
        price = trade['price']
        
        if symbol not in self.positions:
            self.positions[symbol] = {'qty': 0, 'avg_price': 0.0, 'last_update': str(datetime.now())}
        
        pos = self.positions[symbol]
        
        if side == "BUY":
            total_cost = pos['qty'] * pos['avg_price'] + qty * price
            pos['qty'] += qty
            pos['avg_price'] = total_cost / pos['qty'] if pos['qty'] > 0 else 0.0
        elif side == "SELL":
            pos['qty'] -= qty
            if pos['qty'] < 0:
                logger.warning(f"Over-sold {symbol}")
                pos['qty'] = 0
            if pos['qty'] == 0:
                pos['avg_price'] = 0.0
        
        pos['last_update'] = str(datetime.now())
        self._save()
    
    def get_position(self, symbol: str) -> Optional[Dict]:
        """Get position for symbol."""
        return self.positions.get(symbol)
    
    def get_all_positions(self) -> Dict:
        """Get all positions."""
        return self.positions.copy()
    
    def close_all(self):
        """Close all positions."""
        self.positions = {}
        self._save()
        logger.info("All positions closed")
    
    def _save(self):
        """Save positions to JSON."""
        safe_write_json(self.positions, self.positions_path)
```

### exec/equity_curve.py
```python
"""Equity curve tracker."""

import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import List
from loguru import logger
from ..config import config
from ..exec.position_tracker import PositionTracker

class EquityCurve:
    """Track equity over time."""
    
    def __init__(self, initial_cash: float = 100_000):
        self.initial_cash = initial_cash
        self.cash = initial_cash
        self.equity_path = Path(config.storage.equity_path)
        self.curve = []
        self.position_tracker = PositionTracker()
    
    def update(self, prices: Dict[str, float], cash: float):
        """Update equity with current prices."""
        positions_value = 0.0
        
        for symbol, qty_data in self.position_tracker.get_all_positions().items():
            qty = qty_data['qty']
            if symbol in prices and qty > 0:
                positions_value += qty * prices[symbol]
        
        equity = cash + positions_value
        
        # Calculate drawdown
        if self.curve:
            peak = max([e['equity'] for e in self.curve])
            drawdown = (equity / peak - 1.0) if peak > 0 else 0.0
        else:
            drawdown = 0.0
        
        self.curve.append({
            'date': datetime.now(),
            'equity': equity,
            'cash': cash,
            'positions_value': positions_value,
            'drawdown': drawdown
        })
        
        self.cash = cash
    
    def save(self):
        """Save equity curve to CSV."""
        if not self.curve:
            return
        
        df = pd.DataFrame(self.curve)
        df.to_csv(self.equity_path, index=False)
        logger.info(f"Equity curve saved: {len(df)} points")
    
    def get_last_equity(self) -> float:
        """Get last equity value."""
        if self.curve:
            return self.curve[-1]['equity']
        return self.initial_cash
```

---

## 5. CLI - NEW COMMAND: `run` (src/volensy/cli.py)

Add new command to CLI:

```python
@app.command()
def run(
    universe: str = typer.Option("file:src/volensy/data/symbols.csv", help="Universe selection"),
    top: int = typer.Option(10, help="Top N stocks to consider"),
    entry: str = typer.Option("score>=80", help="Entry condition"),
    exit: str = typer.Option("score<70", help="Exit condition"),
    initial_cash: float = typer.Option(100_000, help="Initial cash"),
):
    """Run paper trading simulation (v1.2)."""
    from ..exec import PaperBroker, PositionTracker, EquityCurve
    
    logger.info("Starting paper trading run (v1.2)...")
    
    # Setup
    broker = PaperBroker()
    positions = PositionTracker()
    equity = EquityCurve(initial_cash)
    
    # Fetch data
    symbols = _get_universe_symbols(universe)
    end = datetime.now().strftime("%Y-%m-%d")
    start = (datetime.now() - timedelta(days=config.backtest_lookback_days)).strftime("%Y-%m-%d")
    
    data = load_multiple_stocks(symbols, start, end)
    
    # Screen
    engine = ScreenEngine()
    results = engine.screen(data)
    
    # Log signals
    engine.log_signals(data, results['symbol'].tolist()[:top])
    
    # Simple entry/exit logic (can be enhanced)
    for symbol in results['symbol'].head(top):
        if symbol not in data:
            continue
        
        score = results[results['symbol'] == symbol]['score'].iloc[0]
        
        # Entry
        if eval(entry.replace('score', str(score))):
            if not positions.get_position(symbol):
                qty = int(initial_cash / 10 / data[symbol]['close'].iloc[-1])
                broker.create_order(symbol, "BUY", qty, data[symbol]['close'].iloc[-1], 
                                  f"entry:score={score:.0f}")
                positions.apply_trade({
                    'symbol': symbol,
                    'side': 'BUY',
                    'qty': qty,
                    'price': data[symbol]['close'].iloc[-1]
                })
        
        # Exit
        elif positions.get_position(symbol):
            if eval(exit.replace('score', str(score))):
                pos = positions.get_position(symbol)
                broker.create_order(symbol, "SELL", pos['qty'], data[symbol]['close'].iloc[-1],
                                  f"exit:score={score:.0f}")
                positions.apply_trade({
                    'symbol': symbol,
                    'side': 'SELL',
                    'qty': pos['qty'],
                    'price': data[symbol]['close'].iloc[-1]
                })
    
    # Update equity
    current_prices = {sym: df['close'].iloc[-1] for sym, df in data.items()}
    equity.update(current_prices, equity.cash)
    equity.save()
    
    # Display results
    console.print(f"[green]✓ Paper run complete[/green]")
    console.print(f"  Orders: {len(broker.get_orders())}")
    console.print(f"  Trades: {len(broker.get_trades())}")
    console.print(f"  Equity: ${equity.get_last_equity():,.2f}")
```

Add more commands:

```python
@app.command()
def positions():
    """Show current positions."""
    from ..exec import PositionTracker
    pos_tracker = PositionTracker()
    all_pos = pos_tracker.get_all_positions()
    
    if not all_pos:
        console.print("[yellow]No open positions[/yellow]")
        return
    
    table = Table(title="Open Positions")
    table.add_column("Symbol")
    table.add_column("Qty")
    table.add_column("Avg Price")
    table.add_column("Last Update")
    
    for symbol, pos in all_pos.items():
        table.add_row(symbol, str(pos['qty']), f"${pos['avg_price']:.2f}", pos['last_update'])
    
    console.print(table)

@app.command()
def close_all():
    """Close all positions."""
    from ..exec import PositionTracker
    pos_tracker = PositionTracker()
    pos_tracker.close_all()
    console.print("[green]✓ All positions closed[/green]")

@app.command()
def dataset(
    start: str = typer.Option(None, help="Start date"),
    end: str = typer.Option(None, help="End date"),
    horizons: List[int] = typer.Option([5, 10], help="Forward horizons"),
    thresholds: List[float] = typer.Option([0.01, 0.02], help="Return thresholds"),
):
    """Build ML dataset (v1.2)."""
    from ..ml.dataset import build_dataset
    
    # Implementation placeholder
    console.print("[yellow]ML dataset generation - coming soon[/yellow]")
```

---

## 6. ML DATASET (NEW: src/volensy/ml/)

Create ml/ directory and dataset.py:

### ml/__init__.py
```python
"""ML dataset generation (v1.2)."""

from .dataset import build_dataset

__all__ = ["build_dataset"]
```

### ml/dataset.py
```python
"""Build ML dataset from signals and prices."""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from ..config import config

def build_dataset(symbols: List[str], start: str, end: str, 
                  horizons: List[int] = [5, 10], 
                  thresholds: List[float] = [0.01, 0.02]) -> Path:
    """Build ML dataset with features and labels."""
    
    # Load signals data
    signals_path = Path(config.storage.signals_path)
    if not signals_path.exists():
        logger.warning("No signals data found. Run 'screen' first.")
        return None
    
    signals_df = pd.read_parquet(signals_path)
    
    # Add features
    features = []
    for _, row in signals_df.iterrows():
        feat = {
            'rsi': row.get('rsi', 50),
            'ema_ratio': row.get('ema50', 100) / row.get('ema200', 100) if row.get('ema200') else 1.0,
            'atr_pct': (row.get('atr14', 0) / row.get('close', 1)) * 100 if row.get('close') else 0,
            'donchian_width': ((row.get('donchian_h', 100) - row.get('donchian_l', 100)) / row.get('close', 1)) * 100 if row.get('close') else 0,
            'score': row.get('score', 50),
        }
        features.append(feat)
    
    features_df = pd.DataFrame(features)
    
    # Add labels (placeholder - would need forward returns)
    for horizon in horizons:
        for threshold in thresholds:
            features_df[f'label_{horizon}d@{threshold}'] = None  # Would calculate from future prices
    
    # Save
    timestamp = datetime.now().strftime("%Y%m%d")
    output_path = Path(config.storage.datasets_dir) / f"volensy_dataset_{timestamp}.parquet"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    features_df.to_parquet(output_path, index=False)
    
    logger.info(f"Dataset saved to {output_path}")
    return output_path
```

---

## 7. ACCEPTANCE CRITERIA

✅ storage/ directory created with subdirectories
✅ signals.parquet appended after screen
✅ orders.parquet, trades.parquet updated after run
✅ positions.json stores open positions
✅ equity.csv tracks equity over time
✅ dataset command generates parquet with features + labels
✅ All new features are optional/flags-controlled

---

## README Updates (README_V1.2.md)

Add sections:
- Local-Only Persistence
- Paper Trading
- ML Dataset Generation
- New CLI commands (run, positions, close-all, dataset)
- Storage structure overview

---

## TESTS (tests/test_*.py)

Add:
- test_storage_rotation.py
- test_position_tracker.py
- test_paper_broker.py
- test_equity_curve.py

---

## NOTES

- All v1.1 functionality remains intact
- New features are additive, not breaking
- Storage uses local files only (no DB)
- ML dataset is a foundation for future training

