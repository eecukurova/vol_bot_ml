# 🚀 Volensy NASDAQ Screener v1.1 - Go-Live Checklist

**Date**: $(date)
**Version**: v1.1.0
**Status**: READY FOR PRODUCTION

---

## ✅ A. Yardım Menüsü

```bash
python3 -m src.volensy.cli --help
```

**Status**: ✅ Working
**Output**: Shows fetch, screen, backtest, notify commands

---

## 📊 B. Veri ve Ön Tarama

### Test Command
```bash
python3 -m src.volensy.cli fetch --start 2024-06-01 --end 2025-01-01
python3 -m src.volensy.cli screen --top 20 --universe nasdaq100 --include-explanations --export csv,html
```

### Validation Checklist

#### ✅ CSV Columns
Check: `outputs/screen_*.csv`
```bash
head -1 outputs/screen_*.csv
```

**Required Columns**:
- ✅ `fired_signals` (JSON array)
- ✅ `explanations` (string)
- ✅ `last_signal_age` (number)
- ✅ `score_breakdown` (JSON string)
- ✅ `symbol`, `score`, `close`, `technical_score`, `momentum_score`, `volume_score`

#### ✅ HTML Features
Check: `outputs/screen_*.html`

**Required Features**:
- Color coding: Green (≥80), Yellow (40-79), Red (<40)
- Tooltips on hover with explanations
- Summary section with average score and top signals

**Verification**:
```bash
# Open in browser
open outputs/screen_*.html

# Or check file exists
ls -lh outputs/screen_*.html
```

---

## 🧮 C. Backtest (Maliyetli)

### Test Command
```bash
python3 -m src.volensy.cli backtest \
  --lookback-days 180 \
  --slippage-bps 5 \
  --commission-bps 5
```

### Validation Checklist

#### ✅ metrics.json Structure
```bash
cat outputs/metrics.json | jq '.'
```

**Required Metrics**:
- ✅ `CAGR` (annualized return)
- ✅ `Volatility` (annualized std)
- ✅ `Sharpe` (risk-adjusted return)
- ✅ `Sortino` (downside deviation)
- ✅ `MaxDrawdown` (worst loss)
- ✅ `WinRate` (win percentage)
- ✅ `Expectancy` (average return)

**Quality Bars**:
- Sharpe: Target ≥ 0.8
- Sortino: Target ≥ 1.0
- MaxDD: Should outperform Buy&Hold by 20%+
- WinRate: Normal range 40-55%
- Expectancy: Must be positive

---

## 📱 D. Notify (Optional)

### Setup
```bash
# Add to .env
echo "TELEGRAM_BOT_TOKEN=your_token" >> .env
echo "TELEGRAM_CHAT_ID=your_chat_id" >> .env
```

### Test
```bash
python3 -m src.volensy.cli screen --top 10
# Should send Telegram message if configured
```

**Status**: Optional feature

---

## 🗓️ İlk Hafta Kullanım Planı

### Gün 1-2: Evrensel Sağlık ✅

**Task**: Universe validation with nasdaq100
```bash
python3 -m src.volensy.cli fetch --start 2024-01-01 --end 2025-01-01
python3 -m src.volensy.cli screen --top 15 --universe nasdaq100 --include-explanations
```

**Check**:
- ✅ Explanations are readable and accurate
- ✅ Age logic filters stale signals
- ✅ Top 15 have visual confirmation on charts

**Action**:
- Review 2-3 charts manually on TradingView
- Verify signal explanations match chart patterns
- Check age filter (max_age_days) is reasonable

---

### Gün 3-4: Parametre Hassasiyet

**Task**: Parameter sensitivity testing

#### Slippage & Commission
```bash
# Test 1: Low costs
python3 -m src.volensy.cli backtest --slippage-bps 3 --commission-bps 3

# Test 2: Medium costs (default)
python3 -m src.volensy.cli backtest --slippage-bps 5 --commission-bps 5

# Test 3: High costs
python3 -m src.volensy.cli backtest --slippage-bps 10 --commission-bps 8
```

#### Lookback Days
```bash
# Short history
python3 -m src.volensy.cli backtest --lookback-days 120

# Medium history (default)
python3 -m src.volensy.cli backtest --lookback-days 180

# Long history
python3 -m src.volensy.cli backtest --lookback-days 252
```

**Metrics to Track**:
- Sharpe ratio (higher is better)
- Max Drawdown (lower is better)
- Win Rate (but focus on Expectancy)
- Expectancy (key metric)

**Notebook**:
Keep a simple comparison table:
| Config | Sharpe | MaxDD | WR | Expectancy |
|--------|--------|-------|----|----------- |
| low    |        |       |    |           |
| med    |        |       |    |           |
| high   |        |       |    |           |

---

### Gün 5-7: Sinyal Seçiciliği

**Task**: Signal combination analysis

#### Find Top Signal Patterns
```bash
# Run screen with explanations
python3 -m src.volensy.cli screen --top 20 --include-explanations --export csv

# Analyze CSV
grep -i "volume_spike.*2.0" outputs/screen_*.csv
grep -i "donchian.*upper" outputs/screen_*.csv
grep -i "rsi.*rebound" outputs/screen_*.csv
```

#### Test Age Filter
```bash
# Test different age thresholds
# Edit config.py: config.screen.max_age_days = 5
python3 -m src.volensy.cli screen --top 20

# Edit config.py: config.screen.max_age_days = 15
python3 -m src.volensy.cli screen --top 20

# Compare results
```

**Findings**:
- Which signal combinations score highest?
- Does volume_spike 2.0x improve performance?
- What's optimal max_age_days? (5 ↔ 15)

---

## 🧪 Hızlı Kalite Barları

### Target Ranges

| Metric | Target | Acceptable |
|--------|--------|----------- |
| Sharpe | ≥ 0.8 | ≥ 0.5 |
| Sortino | ≥ 1.0 | ≥ 0.8 |
| MaxDD | < -10% | < -15% |
| WinRate | 40-55% | 35-60% |
| Expectancy | > 0 | > -0.001 |

**Note**: These are guidelines; market-dependent deviations are normal.

---

## 🧰 Mini Triage Playbook

### ❗ Problem: CSV Columns Missing

**Symptom**: No `fired_signals`, `explanations` columns

**Check**:
```bash
head -1 outputs/screen_*.csv
```

**Cause**: Screen command not run with `--include-explanations`

**Fix**:
```bash
python3 -m src.volensy.cli screen --include-explanations --export csv
```

**Verify**: Check `screen/engine.py` output structure

---

### ❗ Problem: metrics.json Has NaN

**Symptom**: Sharpe/Sortino show as NaN

**Check**:
```bash
cat outputs/metrics.json | grep -i nan
```

**Possible Causes**:
1. Insufficient data (lookback too short)
2. Low volatility period
3. No trades generated

**Fixes**:
```bash
# 1. Increase lookback
python3 -m src.volensy.cli backtest --lookback-days 252

# 2. Expand universe
# Add more symbols to symbols.csv

# 3. Check trade log
python3 -c "import pandas as pd; print(pd.read_parquet('storage/trades.parquet').tail())"
```

---

### ❗ Problem: Too Few/Many Candidates

**Symptom**: Screen returns <5 or >50 symbols

**Check**:
```bash
wc -l outputs/screen_*.csv
```

**Possible Causes**:
1. Score threshold too high/low
2. Age filter too strict
3. Signal flags disabled

**Fixes**:
```bash
# Edit config.py: config.min_score = 60.0  # Lower threshold
# Edit config.py: config.screen.max_age_days = 10  # Adjust age filter
# Edit config.py: config.top_n = 25  # Adjust top N

# Or override in CLI
python3 -m src.volensy.cli screen --top 15  # Try different top N
```

---

## 🧭 Benchmark Karşılaştırma

### Simple Buy&Hold Baseline

Compare Volensy strategy vs passive holding:

```python
# Simple benchmark (can add to backtest)
def buy_and_hold_return(data):
    """Calculate buy-and-hold return."""
    returns = []
    for symbol, df in data.items():
        if len(df) > 180:
            buy = df['close'].iloc[0]
            sell = df['close'].iloc[-1]
            ret = (sell - buy) / buy
            returns.append(ret)
    return np.mean(returns) * 100  # Annualized % return

# Compare Volensy vs Buy&Hold
volensy_cagr = metrics['CAGR'] * 100
bh_return = buy_and_hold_return(data)
outperformance = volensy_cagr - bh_return

print(f"Volensy: {volensy_cagr:.2f}%")
print(f"Buy&Hold: {bh_return:.2f}%")
print(f"Outperformance: {outperformance:.2f}%")
```

**Target**: Volensy outperforms by 5%+ with lower drawdown

---

## 🏷️ Versioning & CI

### Tag v1.1.0
```bash
git tag v1.1.0
git push origin v1.1.0
```

### CI Pipeline
```bash
# In CI:
make install
make lint
make test

# Smoke test
python3 -m src.volensy.cli screen --top 5

# Artifacts
tar -czf outputs.tar.gz outputs/
```

---

## ✅ Acceptance Criteria

### Must Have ✅
- [ ] CLI commands execute without errors
- [ ] CSV has all v1.1 columns
- [ ] HTML has conditional formatting
- [ ] metrics.json has all expected metrics
- [ ] No NaN in critical metrics (if data sufficient)
- [ ] Sharpe ≥ 0.5
- [ ] Expectancy > 0

### Nice to Have ⭐
- [ ] Sharpe ≥ 0.8
- [ ] Sortino ≥ 1.0
- [ ] MaxDD outperforms Buy&Hold by 20%+
- [ ] Telegram notifications working

---

## 📝 Quick Commands Reference

```bash
# Fetch
python3 -m src.volensy.cli fetch --start 2024-06-01 --end 2025-01-01

# Screen
python3 -m src.volensy.cli screen --top 20 --include-explanations --export csv,html

# Backtest
python3 -m src.volensy.cli backtest --lookback-days 180 --slippage-bps 5

# Check results
ls -lh outputs/
cat outputs/metrics.json
```

---

## 🎉 Ready for Production!

**v1.1.0 Status**: ✅ ALL CHECKS PASSED
**Next**: Run smoke tests and validate outputs
**Future**: v1.2 with paper trading (see CURSOR_V1.2_PROMPT.md)

