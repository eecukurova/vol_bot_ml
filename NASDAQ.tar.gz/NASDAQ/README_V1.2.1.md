# 📊 Volensy NASDAQ Screener v1.2.1

**Complete automation, reporting, and hotfixes for v1.2**

---

## 🚀 What's New in v1.2.1

### Hotfixes ✅
1. **Signal Logging Integration**
   - Screen automatically logs to `storage/signals.parquet`
   - Includes: ts, symbol, close, rsi, ema50, ema200, atr14, donchian_h, donchian_l, fired_signals, explanations, score, score_breakdown

2. **Forward Returns in Dataset**
   - Proper forward log return calculation
   - Labels: `label_Nd@{threshold}` = 1 if `fwd_ret >= threshold`, else 0
   - Drops NaN/inf and trims last max(horizons) rows

3. **Close-All with Latest Prices**
   - Uses `latest_close()` from yfinance API
   - Falls back to avg_price if API fails
   - Updates trades, equity, and positions

### New Features ✅
4. **Daily Automation Script**
   - `scripts/daily_run.sh` for full workflow
   - `make daily` to run complete pipeline
   - `make smoke` for quick test
   - `make testall` for pytest

5. **Daily HTML Report**
   - `python3 -m src.volensy.cli report --top 20`
   - 3-card layout: Top Candidates, Signal Activity (7d), Equity Snapshot
   - Auto-generates from latest screen CSV

---

## 📖 Usage Guide

### Quick Start
```bash
cd ~/ATR/NASDAQ

# Complete daily run
make daily

# Or step by step:
python3 -m src.volensy.cli fetch --start 2024-06-01 --end 2025-01-01
python3 -m src.volensy.cli screen --top 10 --include-explanations --export csv,html
python3 -m src.volensy.cli run --top 10
python3 -m src.volensy.cli close-all
python3 -m src.volensy.cli dataset --start 2024-01-01 --end 2025-01-01 --horizons 5,10 --thresholds 0.01,0.02
python3 -m src.volensy.cli report --top 20
```

### CLI Commands

```bash
# Fetch data
python3 -m src.volensy.cli fetch --start 2024-01-01 --end 2025-01-01

# Screen candidates
python3 -m src.volensy.cli screen --top 20 --include-explanations --export csv,html

# Paper trading
python3 -m src.volensy.cli run --top 10 --initial-cash 100000

# Check positions
python3 -m src.volensy.cli positions

# Close all positions
python3 -m src.volensy.cli close-all

# Build ML dataset
python3 -m src.volensy.cli dataset --horizons 5,10 --thresholds 0.01,0.02

# Generate daily report
python3 -m src.volensy.cli report --top 20

# Backtest
python3 -m src.volensy.cli backtest --lookback-days 180

# Notify via Telegram
python3 -m src.volensy.cli notify --top 10
```

---

## 🔧 Make Commands

```bash
make help       # Show all commands
make daily      # Run daily automation script
make smoke      # Quick smoke test
make testall    # Run all tests
make lint       # Run linters
make clean      # Clean cache and outputs
```

---

## 📁 Storage Structure

After running, check:
```
storage/
├── signals.parquet        # Signal snapshots (from screen)
├── orders.parquet         # Order records (from run)
├── trades.parquet          # Trade records (from run)
├── positions.json          # Position state (from run)
├── equity.csv             # Equity curve (from run)
└── datasets/
    └── volensy_dataset_YYYYMMDD.parquet

outputs/
├── screen_YYYYMMDD_HHMMSS.csv
├── screen_YYYYMMDD_HHMMSS.html
└── daily_report_YYYYMMDD.html
```

---

## 📊 Dataset Columns

After running `dataset`:

**Features**:
- `ts`, `symbol`, `close`
- `rsi`, `ema50`, `ema200`, `ema_ratio`
- `atr14`, `atr_pct`
- `donchian_h`, `donchian_l`, `donchian_width`

**Labels**:
- `fwd_ret_5d`, `fwd_ret_10d` (forward log returns)
- `label_5d@0.01`, `label_5d@0.02`, `label_10d@0.01`, `label_10d@0.02`

---

## 🎯 Daily Automation (Cron)

Add to crontab for daily runs at 17:00:

```bash
# Edit crontab
crontab -e

# Add this line (adjust path as needed)
0 17 * * * cd /path/to/ATR/NASDAQ && ./scripts/daily_run.sh >> logs/daily_$(date +\%Y\%m\%d).log 2>&1
```

---

## 🧪 Testing

```bash
# Smoke test
make smoke

# All tests
make testall

# Specific test
pytest tests/test_storage_utilities.py -v
```

---

## 📈 Features

### v1.2 Features (Production Ready)
- ✅ Enhanced configuration (6 sections)
- ✅ SignalResult with explanations
- ✅ Parallel data fetching
- ✅ Data validation (min_bars, NaN handling)
- ✅ Professional backtesting with costs
- ✅ Enhanced metrics (Sharpe, Sortino, CAGR)
- ✅ Conditional HTML export
- ✅ CSV with v1.1 columns
- ✅ Age filtering
- ✅ Score breakdown

### v1.2 Local Persistence
- ✅ Local storage (parquet/JSON/CSV)
- ✅ Storage utilities (rotate, safe I/O)
- ✅ Paper broker (order/trade execution)
- ✅ Position tracker (JSON state)
- ✅ Equity curve (CSV tracking)
- ✅ ML dataset framework

### v1.2.1 Hotfixes
- ✅ Signal logging integration
- ✅ Forward returns in dataset
- ✅ Close-all with latest prices

### v1.2.1 New Features
- ✅ Daily automation script
- ✅ Make targets (daily, smoke, testall)
- ✅ Daily HTML report

---

## 🎉 Status

**Version**: v1.2.1  
**Status**: ✅ Production Ready  
**Files**: 50+ Python modules  
**Tests**: 8 test files  
**Documentation**: 20+ files

---

## 🚀 Next Steps

1. Test daily run: `make daily`
2. Set up cron for automation
3. Monitor equity and positions
4. Generate reports: `python3 -m src.volensy.cli report`
5. Build ML models from dataset

**Happy Trading! 📈**

