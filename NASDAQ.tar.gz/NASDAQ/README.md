# Volensy NASDAQ Screener v1.0

A modular stock screening system for NASDAQ with signal scoring, backtesting, and Telegram notifications.

## Features

- 📊 **Multi-signal Detection**: EMA, RSI, Volume, Donchian, 52w signals
- 🎯 **Composite Scoring**: Weighted technical/momentum/volume scores
- 📈 **Quick Backtesting**: Simple rule-based simulator with TP/SL
- 📱 **Telegram Notifications**: Automated top stock alerts
- 💾 **CSV/HTML Export**: Structured outputs for analysis
- 🔄 **Caching**: Efficient data fetching with cache support

## Installation

1. **Clone and setup**:
```bash
cd ~/ATR/NASDAQ
make venv
source venv/bin/activate
make install
```

2. **Configure**:
```bash
cp env.example .env
# Edit .env with your API keys (optional)
```

## Quick Start

### 1. Fetch Data
```bash
python -m src.volensy.cli fetch --start 2024-01-01 --end 2025-01-01
```

### 2. Screen Stocks
```bash
python -m src.volensy.cli screen --top 20 --export csv,html
```

### 3. Run Backtest
```bash
python -m src.volensy.cli backtest --lookback-days 180
```

### 4. Get Notifications (optional)
```bash
python -m src.volensy.cli notify --top 10
```

## Signals

The screener uses multiple signals:

1. **EMA Trend** (`ema_trend.py`): Bull/bear detection from EMA crossover
2. **RSI Rebound** (`rsi_rebound.py`): Oversold bounce signals
3. **Volume Spike** (`volume_spike.py`): Unusual volume detection
4. **Donchian Breakout** (`donchian_breakout.py`): Channel breakout
5. **52-week Setup** (`hi52_setup.py`): Price position in 52w range

## Scoring

Composite score (0-100) calculated from:
- **Technical** (60%): EMA trend signals
- **Momentum** (20%): RSI, Donchian, 52w signals
- **Volume** (20%): Volume spike signals

## Configuration

Edit `src/volensy/config.py` or set environment variables:

```env
DATA_SOURCE=yfinance
FINNHUB_API_KEY=your_key
TELEGRAM_BOT_TOKEN=your_token
TELEGRAM_CHAT_ID=your_chat_id
```

## Project Structure

```
volensy_nasdaq_screener/
├── src/volensy/
│   ├── config.py          # Configuration
│   ├── logging.py         # Logging setup
│   ├── utils.py           # Utilities
│   ├── cli.py             # CLI entry point
│   ├── data/              # Symbols CSV
│   ├── data_fetcher/      # Data loading
│   ├── indicators/        # Technical indicators
│   ├── signals/          # Signal detection
│   ├── scoring/           # Score calculation
│   ├── screen/           # Screening engine
│   ├── backtest/         # Backtesting
│   ├── notify/           # Telegram notifications
│   └── export/           # CSV/HTML export
├── tests/                # Unit tests
└── outputs/              # Generated files
```

## Development

```bash
# Run tests
make test

# Lint code
make lint

# Format code
make fmt

# Clean artifacts
make clean
```

## Limitations

- **Data Quality**: yfinance data may have gaps for delisted stocks
- **Backtest Simplicity**: Quick simulator, not a full backtesting framework
- **Single Timeframe**: Currently supports daily data only

## License

MIT
