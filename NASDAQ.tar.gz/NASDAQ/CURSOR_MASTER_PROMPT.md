# Cursor Master Prompt – Volensy NASDAQ Screener v1.0

**Amaç**: NASDAQ hisseleri için modüler bir screener + sinyal puanlama + hızlı backtest + Telegram bildirim sistemi. Mimari, daha önceki Volensy şablonlarıyla uyumlu; genişletilebilir, kararlı, testli ve logs-first.

---

## 1️⃣ Tech Stack & Standartlar

**Python 3.11+**

**Paketler**: 
- pandas, numpy, yfinance, ta, vectorbt
- scipy, pydantic, python-dotenv, loguru, tqdm, requests, rich, tenacity, typer (CLI), orjson
- Opsiyonel: finnhub-python (API key varsa), supabase (opsiyonel persist)

**Kod standartları**: 
- type hints zorunlu
- docstring Google tarzı
- ruff + black + mypy

**Test**: 
- pytest + örnek fixture'lar
- küçük veriyle hızlı testler

**OS**: 
- cross-platform (Mac/Linux/Win)

---

## 2️⃣ Ürün Kapsamı (MVP)

### DataFetcher: 
- NASDAQ sembol listesi (örnek liste iç/dosya), OHLCV indir, caching. 
- Kaynak: yfinance (default), Finnhub opsiyon.

### Indicators: 
- EMA 50/200, RSI(14), ATR(14), Donchian(20), 52w High/Low, Ortalama Hacim(20).

### Signals (modüler bloklar):
- `ema_trend`: EMA50 > EMA200 (bull) veya tersi (bear)
- `rsi_rebound`: RSI < 30'dan > 30'a dönüş veya RSI 40–60 band filtresi
- `volume_spike`: Günlük hacim > 1.5 × 20 günlük ort.
- `donchian_breakout`: 20-gün üst/alt kırılım
- `52w_setup`: Fiyat 52w low'dan x% uzaklık ve 52w high'a yakınlık metriği

### ScoringEngine: 
- Ağırlıklar varsayılan: Teknik(60) Momentum(20) Hacim/Vol(20). 
- 0–100 skor, açıklamalı breakdown.

### Filter/Screen: 
- Kullanıcı kural setini konfigden al (örn. RSI<35, EMA trend bull, volume_spike true…).

### Backtest (Quick Sim): 
- Basit kurallı: Entry = sinyal onayı barı kapanışı; Exit = ATR×2 SL veya Donchian karşı kırılım; 180 günlük varsayılan aralık. 
- Sonuçlar: Winrate, PF, Sharpe, MaxDD.

### Notify: 
- En yüksek 10 skor için Telegram mesajı (opsiyonel).

### Export: 
- CSV + HTML rapor (mini tablo + metrikler).

---

## 3️⃣ Proje Yapısı

```
volensy_nasdaq_screener/
  README.md
  pyproject.toml
  requirements.txt
  .env.example
  .gitignore
  Makefile
  docker/
    Dockerfile
  src/
    volensy/
      __init__.py
      config.py            # Pydantic config & feature flags
      logging.py           # Loguru setup
      utils.py             # cache, retry, time utils
      data/
        symbols.csv        # örnek NASDAQ sembolleri (20-30 örnek)
      data_fetcher/
        __init__.py
        yfinance_client.py
        finnhub_client.py  # opsiyonel
        loader.py          # sembol listesi & OHLCV unify
      indicators/
        __init__.py
        core.py            # EMA, RSI, ATR, Donchian, 52w
      signals/
        __init__.py
        ema_trend.py
        rsi_rebound.py
        volume_spike.py
        donchian_breakout.py
        hi52_setup.py
      scoring/
        __init__.py
        scorer.py          # ağırlıklar, normalize, composite score
      screen/
        __init__.py
        engine.py          # filtre uygula, en iyi N
      backtest/
        __init__.py
        quick_sim.py       # basit kural tabanlı test
      notify/
        __init__.py
        telegram.py        # opsiyonel
      export/
        __init__.py
        to_csv.py
        to_html.py         # minimal tablo + metrik
      cli.py               # Typer CLI entrypoint
  tests/
    conftest.py
    test_indicators.py
    test_signals.py
    test_scoring.py
    test_backtest.py
  .ruff.toml
  mypy.ini
```

---

## 4️⃣ Konfig & Feature Flags

### .env.example:
```env
FINNHUB_API_KEY=
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
DATA_SOURCE=yfinance   # yfinance|finnhub
USE_SUPABASE=false
```

### config.py:
- Tarih aralığı, sembol kaynak dosyası, output klasörü
- Ağırlıklar: `weights = { "technical": 0.6, "momentum": 0.2, "volume": 0.2 }`
- Feature flags: use_rsi_rebound, use_donchian_breakout, notify_telegram…

---

## 5️⃣ Skor & Sinyal Detayı

Her sinyal fonksiyonu pd.Series[bool] veya skor/şiddet döndürsün.

### scorer.py:
- normalize fonksiyonları (0–1)
- composite score hesaplama, açıklamalı breakdown (dict)

Örnek skorlama:
- ema_trend: bull = 1, bear = 0 (veya -1) → normalize
- rsi_rebound: trigger varsa +0.3 katkı
- volume_spike: oranı 1.5x ise +0.2, 2x ise +0.3
- donchian_breakout: true ise +0.3
- hi52_setup: 52w high'a yakınlık pozitif katkı; low'a yakınlık negatif

---

## 6️⃣ CLI Komutları (Typer)

```
python -m volensy.cli fetch --start 2024-01-01 --end 2025-10-27
python -m volensy.cli screen --top 25 --export csv html
python -m volensy.cli backtest --lookback_days 180
python -m volensy.cli notify --top 10
```

---

## 7️⃣ Output

outputs/
- screen_YYYYMMDD_HHMM.csv
- screen_YYYYMMDD_HHMM.html
- backtest_YYYYMMDD_HHMM.csv (trade logs + summary)
- metrics.json (PF, Sharpe, Winrate, MDD)

---

## 8️⃣ Logging & Hata Yönetimi

- loguru ile `logs/volensy.log`
- tenacity ile retry (rate-limit vs.)
- Eksik veri/sıfır hacim vs. dayanıklı akış
- CLI'da rich ile ilerleme barı

---

## 9️⃣ Testler

- Mini OHLCV fixture (yapay 60–120 bar)
- Giriş/çıkış doğrulama, sinyal tutarlılığı, skor aralığı, backtest temel metrikler
- CI-friendly hızlı çalışmalı

---

## 🔟 Geliştirilebilirlik

- Opsiyonel Supabase persiste katmanı (şimdilik interface + feature flag)
- İleride: Optuna ile hiperparametre taraması, çoklu strateji portföy skoru

---

## 1️⃣1️⃣ README İçeriği

- Kurulum, .env örneği, hızlı başlatma, CLI örnekleri, akış diyagramı
- Sinyallerin açıklaması ve yaygın senaryolar
- Limitler & bilinen konular (yfinance data quality, delist/adj issues)

---

## 1️⃣2️⃣ Makefile & Docker

- `make venv / install / lint / test / run`
- Dockerfile: slim image, cache-friendly
- pyproject.toml: bağımlılıklar ve araç konfigleri
- ruff, black, mypy konfig dosyaları

---

## 1️⃣3️⃣ Kabul Kriterleri

- `make install && make test` geçmeli
- `python -m volensy.cli fetch …` veri indirip cache'lemeli
- `screen top N` çıktılarını hem CSV hem HTML üretmeli
- `backtest` en az Winrate, PF, Sharpe, MaxDD vermeli
- (Opsiyonel) notify env doluysa Telegram'a mesaj atmalı
- Kod tipli, modüler, unit testli, loglu olmalı

---

## 1️⃣4️⃣ Örnek Akış (Hızlı Demo)

```bash
python -m volensy.cli fetch --start 2024-01-01 --end 2025-10-27
python -m volensy.cli screen --top 20 --export csv html
python -m volensy.cli backtest --lookback_days 180
python -m volensy.cli notify --top 10  # (opsiyonel)
```

**Not**: Sembol listesi için `src/volensy/data/symbols.csv` içine 20–30 NASDAQ örnek sembol ekleyin (AAPL, MSFT, NVDA, AMD, INTC, AMZN, META, GOOGL, NFLX, TSLA, CRWD, ABNB, PLTR, …). Finnhub key yoksa yfinance ile devam edin.

---

## 1️⃣5️⃣ Teslim Şekli

Tüm dosyalar oluşturulmuş, çalışır örnek veriyle testlenmiş olmalı.

README'de adım adım kurulum ve kullanım.

İlk PR/commit mesajı: `feat: bootstrap Volensy NASDAQ Screener v1.0 (modular, tested, CLI)`

