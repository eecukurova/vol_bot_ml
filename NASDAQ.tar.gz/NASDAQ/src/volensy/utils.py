"""
Utility functions for caching, retry, time operations (v1.2 with storage utilities).
"""

import pickle
import json
import shutil
from pathlib import Path
from functools import wraps
from typing import Any, Callable, TypeVar, Optional
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential
from .config import config

T = TypeVar('T')


def cache_result(filename: str):
    """Simple file-based caching decorator."""
    def decorator(func: Callable[[], T]) -> Callable[[], T]:
        @wraps(func)
        def wrapper(*args, **kwargs):
            cache_file = config.cache_dir / filename
            cache_file.parent.mkdir(exist_ok=True)
            
            # Try to load from cache
            if cache_file.exists():
                try:
                    with open(cache_file, 'rb') as f:
                        return pickle.load(f)
                except Exception:
                    pass
            
            # Compute result
            result = func(*args, **kwargs)
            
            # Save to cache
            try:
                with open(cache_file, 'wb') as f:
                    pickle.dump(result, f)
            except Exception:
                pass
            
            return result
        
        return wrapper
    return decorator


def retry_on_error(max_attempts: int = 3):
    """Retry decorator with exponential backoff."""
    def decorator(func: Callable[[], T]) -> Callable[[], T]:
        @retry(
            stop=stop_after_attempt(max_attempts),
            wait=wait_exponential(multiplier=1, min=2, max=10)
        )
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        
        return wrapper
    return decorator


def get_symbols_file() -> Path:
    """Get path to symbols.csv file."""
    return config.data_dir / "symbols.csv"


def parse_date(date_str: str):
    """Parse date string to datetime."""
    from datetime import datetime
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise ValueError(f"Invalid date format: {date_str}. Use YYYY-MM-DD")


def format_number(num: float, decimals: int = 2) -> str:
    """Format number with commas and decimals."""
    return f"{num:,.{decimals}f}"


def format_percentage(num: float) -> str:
    """Format as percentage."""
    return f"{num:.2f}%"


# v1.2: Storage utilities

def ensure_dirs(*paths: str) -> None:
    """Ensure directories exist for given paths."""
    for path_str in paths:
        path = Path(path_str)
        path.parent.mkdir(parents=True, exist_ok=True)


def rotate_if_big(path_str: str, max_mb: int = 256, keep: int = 3) -> None:
    """
    Rotate file if it exceeds size limit.
    
    Creates path.1, path.2, etc. keeping 'keep' versions.
    """
    path = Path(path_str)
    if not path.exists():
        return
    
    size_mb = path.stat().st_size / (1024 * 1024)
    if size_mb > max_mb:
        # Rotate existing files
        for i in range(keep - 1, 0, -1):
            old_path = Path(f"{path_str}.{i}")
            new_path = Path(f"{path_str}.{i + 1}")
            if old_path.exists():
                shutil.move(str(old_path), str(new_path))
        
        # Create first backup
        if path.exists():
            shutil.copy2(str(path), Path(f"{path_str}.1"))
            logger.info(f"Rotated {path_str} (size: {size_mb:.2f} MB)")


def safe_to_parquet(df, path_str: str, append: bool = False) -> None:
    """Safely write DataFrame to Parquet file."""
    path = Path(path_str)
    ensure_dirs(str(path))
    
    try:
        if append:
            safe_append_parquet(df, path_str)
        else:
            df.to_parquet(path, index=False)
            logger.debug(f"Wrote parquet: {path_str}")
    except Exception as e:
        logger.error(f"Failed to write parquet {path_str}: {e}")


def safe_append_parquet(df, path_str: str) -> None:
    """Safely append DataFrame to existing Parquet file."""
    path = Path(path_str)
    ensure_dirs(str(path))
    rotate_if_big(path_str, config.storage.rotation_max_mb, config.storage.rotation_keep)
    
    try:
        if path.exists():
            existing = __import__('pandas').read_parquet(path)
            combined = __import__('pandas').concat([existing, df], ignore_index=True)
        else:
            combined = df
        
        combined.to_parquet(path, index=False)
        logger.debug(f"Appended to parquet: {path_str}")
    except Exception as e:
        logger.error(f"Failed to append to parquet {path_str}: {e}")


def safe_write_json(obj: dict, path_str: str) -> None:
    """Safely write JSON file."""
    path = Path(path_str)
    ensure_dirs(str(path))
    
    try:
        with open(path, 'w') as f:
            json.dump(obj, f, indent=2, default=str)
        logger.debug(f"Wrote JSON: {path_str}")
    except Exception as e:
        logger.error(f"Failed to write JSON {path_str}: {e}")


def safe_read_json(path_str: str, default: Optional[dict] = None) -> dict:
    """Safely read JSON file."""
    path = Path(path_str)
    
    if not path.exists():
        return default or {}
    
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to read JSON {path_str}: {e}")
        return default or {}


def check_dataset_health(path_str: str) -> dict:
    """
    Check dataset health (NaN/inf ratios).
    
    Args:
        path_str: Path to dataset file
        
    Returns:
        Dict with health statistics
    """
    import pandas as pd
    import numpy as np
    
    try:
        df = pd.read_parquet(path_str)
        
        total_cells = len(df) * len(df.columns)
        nan_cells = df.isna().sum().sum()
        inf_cells = 0
        
        for col in df.select_dtypes(include=[np.number]).columns:
            if (df[col] == float('inf')).any() or (df[col] == float('-inf')).any():
                inf_cells += (df[col] == float('inf')).sum() + (df[col] == float('-inf')).sum()
        
        stats = {
            'rows': len(df),
            'cols': len(df.columns),
            'nan_count': nan_cells,
            'inf_count': inf_cells,
            'nan_ratio': nan_cells / total_cells if total_cells > 0 else 0,
            'is_healthy': nan_cells == 0 and inf_cells == 0
        }
        
        if not stats['is_healthy']:
            logger.warning(f"Dataset health check failed: {stats}")
        
        return stats
    
    except Exception as e:
        logger.error(f"Failed to check dataset health: {e}")
        return {'is_healthy': False, 'error': str(e)}

