"""CSV export module (v1.1 with extra columns)."""

import pandas as pd
from datetime import datetime
from pathlib import Path
from loguru import logger
from ..config import config


def export_to_csv(data: pd.DataFrame, filename_prefix: str = "screen") -> Path:
    """
    Export DataFrame to CSV (v1.1 with explanations, age, breakdown).
    
    Args:
        data: DataFrame to export (should have fired_signals, explanations, etc.)
        filename_prefix: Filename prefix
    
    Returns:
        Path to exported file
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{filename_prefix}_{timestamp}.csv"
    filepath = config.output_dir / filename
    
    try:
        # Ensure all v1.1 columns exist
        if 'fired_signals' not in data.columns:
            data['fired_signals'] = ""
        if 'explanations' not in data.columns:
            data['explanations'] = ""
        if 'last_signal_age' not in data.columns:
            data['last_signal_age'] = None
        if 'score_breakdown' not in data.columns:
            data['score_breakdown'] = ""
        
        # Convert fired_signals from JSON if it's a dict/list
        if 'fired_signals' in data.columns:
            data['fired_signals'] = data['fired_signals'].apply(
                lambda x: "; ".join(x) if isinstance(x, list) else x
            )
        
        data.to_csv(filepath, index=False)
        logger.info(f"Exported to {filepath}")
        return filepath
    
    except Exception as e:
        logger.error(f"Failed to export CSV: {e}")
        raise
