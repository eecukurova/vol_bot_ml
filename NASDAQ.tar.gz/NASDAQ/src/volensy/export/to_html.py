"""HTML export module (v1.1 with conditional formatting and tooltips)."""

import pandas as pd
from datetime import datetime
from pathlib import Path
from loguru import logger
from ..config import config


def export_to_html(data: pd.DataFrame, filename_prefix: str = "screen") -> Path:
    """
    Export DataFrame to HTML (v1.1 with color coding and tooltips).
    
    Args:
        data: DataFrame to export
        filename_prefix: Filename prefix
    
    Returns:
        Path to exported file
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{filename_prefix}_{timestamp}.html"
    filepath = config.output_dir / filename
    
    try:
        # Ensure all v1.1 columns exist
        if 'fired_signals' not in data.columns:
            data['fired_signals'] = ""
        if 'explanations' not in data.columns:
            data['explanations'] = ""
        if 'last_signal_age' not in data.columns:
            data['last_signal_age'] = None
        if 'score_breakdown' not in data.columns:
            data['score_breakdown'] = ""
        
        # Calculate summary metrics
        total_symbols = len(data)
        avg_score = data['score'].mean() if 'score' in data.columns else 0.0
        signal_counts = {}
        if 'fired_signals' in data.columns:
            for _, row in data.iterrows():
                fs = row['fired_signals']
                if isinstance(fs, str):
                    signals = [s.strip() for s in fs.split(',') if s.strip()]
                    for sig in signals:
                        signal_counts[sig] = signal_counts.get(sig, 0) + 1
        
        # Generate HTML
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Volensy NASDAQ Screener v1.1</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }}
        .summary {{
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }}
        th {{
            background-color: #4CAF50;
            color: white;
        }}
        tr:nth-child(even) {{
            background-color: #f9f9f9;
        }}
        .score-high {{
            background-color: #c8e6c9 !important;
            font-weight: bold;
        }}
        .score-medium {{
            background-color: #fff9c4 !important;
        }}
        .score-low {{
            background-color: #ffcdd2 !important;
        }}
        .tooltip {{
            position: relative;
            cursor: help;
        }}
        .tooltip:hover::after {{
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background-color: #333;
            color: white;
            padding: 8px;
            border-radius: 4px;
            white-space: pre-wrap;
            z-index: 1000;
            max-width: 300px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Volensy NASDAQ Screener v1.1</h1>
        <p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
    </div>
    
    <div class="summary">
        <h2>Summary</h2>
        <p><strong>Total Symbols:</strong> {total_symbols}</p>
        <p><strong>Average Score:</strong> {avg_score:.2f}</p>
        <p><strong>Top Signals:</strong> {', '.join(list(signal_counts.keys())[:5]) if signal_counts else 'None'}</p>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Rank</th>
                <th>Symbol</th>
                <th>Score</th>
                <th>Close</th>
                <th>Technical</th>
                <th>Momentum</th>
                <th>Volume</th>
                <th>Signals</th>
                <th>Age (days)</th>
            </tr>
        </thead>
        <tbody>
"""
        
        # Add rows with conditional formatting
        for i, (idx, row) in enumerate(data.iterrows(), 1):
            score = row.get('score', 0)
            score_class = 'score-high' if score >= 80 else 'score-medium' if score >= 40 else 'score-low'
            
            explanations = row.get('explanations', '')
            breakdown = row.get('score_breakdown', '{}')
            tooltip_text = f"Explanations: {explanations}\\nBreakdown: {breakdown}"
            
            symbol = row.get('symbol', 'N/A')
            close = row.get('close', 0)
            tech = row.get('technical_score', 0)
            mom = row.get('momentum_score', 0)
            vol = row.get('volume_score', 0)
            signals = row.get('fired_signals', '')
            age = row.get('last_signal_age', 'N/A')
            
            html += f"""
            <tr class="{score_class}">
                <td>{i}</td>
                <td class="tooltip" data-tooltip="{tooltip_text}">{symbol}</td>
                <td class="tooltip" data-tooltip="{tooltip_text}">{score:.2f}</td>
                <td>${close:.2f}</td>
                <td>{tech:.2f}</td>
                <td>{mom:.2f}</td>
                <td>{vol:.2f}</td>
                <td>{signals if signals else 'None'}</td>
                <td>{age if age != 'N/A' else '-'}</td>
            </tr>
"""
        
        html += """
        </tbody>
    </table>
</body>
</html>
"""
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html)
        
        logger.info(f"Exported to {filepath}")
        return filepath
    
    except Exception as e:
        logger.error(f"Failed to export HTML: {e}")
        raise
