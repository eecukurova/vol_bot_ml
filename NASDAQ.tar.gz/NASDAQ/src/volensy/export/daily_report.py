"""Generate daily HTML report (v1.2.1)."""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional
from loguru import logger
import json

from ..config import config


def build_daily_report(top: int = 20) -> Path:
    """
    Build daily HTML report with screener results and activity.
    
    Args:
        top: Number of top stocks to include
        
    Returns:
        Path to generated HTML file
    """
    logger.info(f"Building daily report (top {top})")
    
    timestamp = datetime.now().strftime("%Y%m%d")
    output_path = Path("outputs") / f"daily_report_{timestamp}.html"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    html_parts = []
    
    # Header
    html_parts.append("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Volensy Daily Report - """ + datetime.now().strftime("%Y-%m-%d") + """</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
            .container { max-width: 1200px; margin: 0 auto; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                      color: white; padding: 30px; border-radius: 10px; margin-bottom: 20px; }
            .header h1 { margin: 0; font-size: 2em; }
            .header p { margin: 5px 0 0 0; opacity: 0.9; }
            .card { background: white; padding: 20px; margin-bottom: 20px; 
                    border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .card h2 { margin-top: 0; color: #333; border-bottom: 2px solid #667eea; 
                       padding-bottom: 10px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
            th { background: #f8f9fa; font-weight: bold; color: #333; }
            tr:hover { background: #f5f5f5; }
            .score-high { color: #28a745; font-weight: bold; }
            .score-medium { color: #ffc107; font-weight: bold; }
            .score-low { color: #dc3545; }
            .stat { display: inline-block; margin: 10px 20px; padding: 15px 20px; 
                    background: #e9ecef; border-radius: 5px; }
            .stat-value { font-size: 2em; font-weight: bold; color: #667eea; }
            .stat-label { color: #666; font-size: 0.9em; }
            .warning { background: #fff3cd; border: 1px solid #ffc107; padding: 15px; 
                       border-radius: 5px; margin: 10px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>📊 Volensy NASDAQ Screener</h1>
                <p>Daily Report - """ + datetime.now().strftime("%Y-%m-%d %H:%M") + """</p>
            </div>
    """)
    
    # Card 1: Top Screener Results
    screen_files = list(Path("outputs").glob("screen_*.csv"))
    if screen_files:
        latest_screen = max(screen_files, key=lambda p: p.stat().st_mtime)
        df_screen = pd.read_csv(latest_screen)
        
        html_parts.append("""
            <div class="card">
                <h2>🏆 Top """ + str(min(top, len(df_screen))) + """ Candidates</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Symbol</th>
                            <th>Score</th>
                            <th>Close</th>
                            <th>RSI</th>
                            <th>EMA Ratio</th>
                            <th>Signals</th>
                        </tr>
                    </thead>
                    <tbody>
        """)
        
        for idx, row in df_screen.head(top).iterrows():
            score = row.get('score', 0)
            score_class = 'score-high' if score >= 60 else ('score-medium' if score >= 40 else 'score-low')
            
            signals = row.get('fired_signals', '[]')
            try:
                signals_list = json.loads(signals) if isinstance(signals, str) else signals
                signals_str = ', '.join(str(s)[:15] for s in signals_list[:3])
            except:
                signals_str = str(signals)[:50]
            
            html_parts.append(f"""
                        <tr>
                            <td>{idx + 1}</td>
                            <td>{row.get('symbol', '-')}</td>
                            <td class="{score_class}">{row.get('score', 0):.1f}</td>
                            <td>${row.get('close', 0):.2f}</td>
                            <td>{row.get('rsi', 0):.1f}</td>
                            <td>{row.get('ema_ratio', 0):.3f}</td>
                            <td title="{row.get('explanations', '')[:200]}">{signals_str}</td>
                        </tr>
            """)
        
        html_parts.append("""
                    </tbody>
                </table>
            </div>
        """)
    else:
        html_parts.append("""
            <div class="card">
                <div class="warning">⚠️ No recent screen results found. Run 'screen' command first.</div>
            </div>
        """)
    
    # Card 2: Signal Activity (last 7 days)
    signals_path = Path(config.storage.signals_path)
    if signals_path.exists():
        try:
            df_signals = pd.read_parquet(signals_path)
            df_signals['ts'] = pd.to_datetime(df_signals['ts'])
            
            # Last 7 days
            cutoff = datetime.now() - timedelta(days=7)
            recent_signals = df_signals[df_signals['ts'] >= cutoff]
            
            if len(recent_signals) > 0:
                signal_counts = recent_signals['symbol'].value_counts().head(10)
                
                html_parts.append("""
                    <div class="card">
                        <h2>📈 Signal Activity (Last 7 Days)</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Symbol</th>
                                    <th>Signals</th>
                                </tr>
                            </thead>
                            <tbody>
                """)
                
                for symbol, count in signal_counts.items():
                    html_parts.append(f"""
                                <tr>
                                    <td>{symbol}</td>
                                    <td>{count}</td>
                                </tr>
                    """)
                
                html_parts.append("""
                            </tbody>
                        </table>
                    </div>
                """)
        except Exception as e:
            logger.error(f"Failed to process signals: {e}")
    
    # Card 3: Equity Snapshot
    equity_path = Path(config.storage.equity_path)
    if equity_path.exists():
        try:
            df_equity = pd.read_csv(equity_path)
            df_equity['timestamp'] = pd.to_datetime(df_equity['timestamp'])
            
            current_equity = df_equity['equity'].iloc[-1]
            max_dd = df_equity['drawdown'].min() if 'drawdown' in df_equity.columns else 0
            initial_equity = df_equity['equity'].iloc[0]
            total_return = ((current_equity - initial_equity) / initial_equity * 100)
            
            html_parts.append(f"""
                <div class="card">
                    <h2>💰 Equity Snapshot</h2>
                    <div class="stat">
                        <div class="stat-value">${current_equity:,.0f}</div>
                        <div class="stat-label">Current Equity</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value">{total_return:+.1f}%</div>
                        <div class="stat-label">Total Return</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value">{max_dd:.1f}%</div>
                        <div class="stat-label">Max Drawdown</div>
                    </div>
                </div>
            """)
        except Exception as e:
            logger.error(f"Failed to process equity: {e}")
    
    # Footer
    html_parts.append("""
        </div>
    </body>
    </html>
    """)
    
    # Write HTML
    html_content = '\n'.join(html_parts)
    output_path.write_text(html_content)
    
    logger.info(f"Daily report saved to {output_path}")
    return output_path

