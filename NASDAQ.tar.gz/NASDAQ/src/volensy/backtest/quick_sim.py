"""
Quick backtest simulator (v1.1 with costs, sizing, and enhanced metrics).
"""

import json
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict
from loguru import logger
from ..config import config

TRADING_DAYS = 252


def _apply_costs(price: float, side: str, qty: float) -> tuple[float, float, float]:
    """
    Apply slippage and commission to price.
    
    Args:
        price: Original price
        side: "BUY" or "SELL"
        qty: Quantity
    
    Returns:
        Tuple of (adjusted_price, slippage, commission)
    """
    cfg = config.bt
    slip = price * (cfg.slippage_bps / 1e4)
    fee = price * (cfg.commission_bps / 1e4)
    
    # Slippage direction
    if side == "BUY":
        px = price + slip
    else:  # SELL
        px = price - slip
    
    # Add commission
    px = px + fee
    
    return px, slip, fee


def _position_size(equity: float, price: float) -> int:
    """
    Calculate position size based on config.
    
    Args:
        equity: Current equity
        price: Entry price
    
    Returns:
        Number of shares (integer)
    """
    cfg = config.bt
    
    if cfg.position_sizing == "fixed_cash":
        cash = cfg.fixed_cash_usd
    else:  # fixed_pct
        cash = equity * cfg.fixed_pct
    
    return max(1, int(cash // price))


def _calculate_metrics(equity_curve: pd.Series, rf: float = 0.0) -> dict:
    """
    Calculate comprehensive backtest metrics.
    
    Args:
        equity_curve: Series of equity values indexed by datetime
        rf: Risk-free rate
    
    Returns:
        Dict with all metrics
    """
    rets = equity_curve.pct_change().dropna()
    
    if len(rets) == 0:
        return {
            "CAGR": 0.0,
            "Volatility": 0.0,
            "Sharpe": 0.0,
            "Sortino": 0.0,
            "MaxDrawdown": 0.0,
            "WinRate": 0.0,
            "Expectancy": 0.0
        }
    
    # Annualized return
    ann_ret = (1 + rets.mean()) ** TRADING_DAYS - 1
    
    # Annualized volatility
    ann_vol = rets.std() * np.sqrt(TRADING_DAYS)
    
    # Sharpe ratio
    sharpe = (ann_ret - rf) / ann_vol if ann_vol > 0 else np.nan
    
    # Sortino ratio (downside deviation)
    neg = rets[rets < 0]
    downside = neg.std() * np.sqrt(TRADING_DAYS) if len(neg) > 0 else np.nan
    sortino = (ann_ret - rf) / downside if downside and downside > 0 else np.nan
    
    # Max drawdown
    rollmax = equity_curve.cummax()
    dd = (equity_curve / rollmax - 1.0)
    maxdd = dd.min()
    
    # Win rate and expectancy
    wins = (rets > 0).mean()
    exp = rets.mean()
    
    return {
        "CAGR": float(ann_ret),
        "Volatility": float(ann_vol),
        "Sharpe": float(sharpe) if not np.isnan(sharpe) else 0.0,
        "Sortino": float(sortino) if not np.isnan(sortino) else 0.0,
        "MaxDrawdown": float(maxdd),
        "WinRate": float(wins),
        "Expectancy": float(exp)
    }


class QuickSimulator:
    """Backtest simulator with v1.1 enhancements."""
    
    def backtest(self, data: Dict[str, pd.DataFrame], initial_equity: float = 100_000) -> dict:
        """
        Run backtest on data with costs, sizing, and enhanced metrics.
        
        Args:
            data: Dict of symbol -> DataFrame
            initial_equity: Starting capital
        
        Returns:
            Dict with backtest metrics
        """
        all_equity_curves = []
        all_trade_logs = []
        
        for symbol, df in data.items():
            if df.empty or len(df) < config.data.min_bars:
                continue
            
            try:
                eq_curve, trades = self._simulate_symbol(symbol, df, initial_equity)
                if not eq_curve.empty:
                    all_equity_curves.append(eq_curve)
                if not trades.empty:
                    all_trade_logs.append(trades)
            
            except Exception as e:
                logger.error(f"Error backtesting {symbol}: {e}")
                continue
        
        # Combine all results
        if not all_equity_curves:
            return self._empty_metrics()
        
        combined_equity = pd.concat(all_equity_curves).sort_index()
        
        # Calculate metrics
        trades_df = pd.concat(all_trade_logs) if all_trade_logs else pd.DataFrame()
        
        if not trades_df.empty:
            wins = trades_df[trades_df['pnl'] > 0]
            losses = trades_df[trades_df['pnl'] < 0]
            
            total_trades = len(trades_df)
            win_rate = len(wins) / total_trades if total_trades > 0 else 0.0
            gross_profit = wins['pnl'].sum() if len(wins) > 0 else 0.0
            gross_loss = abs(losses['pnl'].sum()) if len(losses) > 0 else 0.0
            profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0.0
        else:
            total_trades = 0
            win_rate = 0.0
            profit_factor = 0.0
        
        # Calculate comprehensive metrics
        metrics = _calculate_metrics(combined_equity, rf=config.risk.free_rate)
        metrics['total_trades'] = total_trades
        metrics['win_rate'] = win_rate * 100
        metrics['profit_factor'] = profit_factor
        
        # Write metrics.json if enabled
        if config.export.include_metrics_json:
            self._write_metrics_json(metrics, trades_df)
        
        return metrics
    
    def _simulate_symbol(self, symbol: str, df: pd.DataFrame, equity: float) -> tuple[pd.Series, pd.DataFrame]:
        """Simulate trades for a single symbol with v1.1 costs and sizing."""
        from ..signals import detect_ema_trend, detect_donchian_breakout
        from ..indicators import calculate_atr
        
        position = None
        trade_logs = []
        equity_curve = []
        
        # Calculate signals and indicators
        ema_sig = detect_ema_trend(df, config.ema_short, config.ema_long)
        donchian_sig = detect_donchian_breakout(df, config.donchian_period)
        atr = calculate_atr(df['high'], df['low'], df['close'], config.atr_period)
        
        shares = 0
        
        for i in range(len(df)):
            current_date = df.index[i]
            current_price = df['close'].iloc[i]
            current_atr = atr.iloc[i] if i < len(atr) else 0.0
            
            # Entry logic: EMA trend + Donchian upper breakout
            ema_bull = ema_sig.strength.iloc[i] > 0 if i < len(ema_sig.strength) else False
            donchian_up = donchian_sig.strength.iloc[i] > 0 if i < len(donchian_sig.strength) else False
            
            entry_signal = ema_bull and donchian_up and shares == 0
            
            # Exit logic: opposite signal or stop loss
            exit_signal = False
            if shares > 0 and position is not None:
                exit_signal = (
                    not ema_bull  # Bearish reversal
                    or donchian_sig.strength.iloc[i] < 0  # Lower breakout
                )
            
            # Entry
            if entry_signal:
                qty = _position_size(equity, current_price)
                px, slip, fee = _apply_costs(current_price, "BUY", qty)
                cost = qty * px
                
                if cost <= equity:
                    equity -= cost
                    shares += qty
                    position = {
                        'entry_date': current_date,
                        'entry_price': px,
                        'shares': qty,
                        'sl_distance': current_atr * config.backtest_sl_atr_multiplier
                    }
                    trade_logs.append({
                        'symbol': symbol,
                        'timestamp': current_date,
                        'side': 'BUY',
                        'qty': qty,
                        'price': float(px),
                        'slippage': float(slip),
                        'commission': float(fee),
                        'cost': float(cost),
                        'reason': 'EMA+DON entry'
                    })
            
            # Exit
            if exit_signal and shares > 0 and position is not None:
                px, slip, fee = _apply_costs(current_price, "SELL", shares)
                proceeds = shares * px
                pnl = proceeds - (shares * position['entry_price'])
                pnl_pct = pnl / (shares * position['entry_price']) * 100
                
                equity += proceeds
                trade_logs.append({
                    'symbol': symbol,
                    'timestamp': current_date,
                    'side': 'SELL',
                    'qty': shares,
                    'price': float(px),
                    'slippage': float(slip),
                    'commission': float(fee),
                    'proceeds': float(proceeds),
                    'pnl': float(pnl),
                    'pnl_pct': float(pnl_pct),
                    'reason': 'Signal exit'
                })
                shares = 0
                position = None
            
            # Calculate current equity (including open position)
            current_equity = equity + (shares * current_price)
            equity_curve.append({
                'timestamp': current_date,
                'equity': current_equity
            })
        
        equity_series = pd.DataFrame(equity_curve).set_index('timestamp')['equity']
        trades_df = pd.DataFrame(trade_logs) if trade_logs else pd.DataFrame()
        
        return equity_series, trades_df
    
    def _write_metrics_json(self, metrics: dict, trades_df: pd.DataFrame):
        """Write metrics to JSON file."""
        output_file = config.output_dir / "metrics.json"
        
        output_data = {
            "metrics": metrics,
            "total_trades": len(trades_df) if not trades_df.empty else 0,
            "config": {
                "slippage_bps": config.bt.slippage_bps,
                "commission_bps": config.bt.commission_bps,
                "position_sizing": config.bt.position_sizing,
                "fixed_cash_usd": config.bt.fixed_cash_usd,
                "fixed_pct": config.bt.fixed_pct
            }
        }
        
        try:
            with open(output_file, 'w') as f:
                json.dump(output_data, f, indent=2, default=str)
            logger.info(f"Metrics written to {output_file}")
        except Exception as e:
            logger.error(f"Failed to write metrics: {e}")
    
    def _empty_metrics(self) -> dict:
        """Return empty metrics dict."""
        return {
            'total_trades': 0,
            'win_rate': 0.0,
            'profit_factor': 0.0,
            'sharpe': 0.0,
            'max_drawdown': 0.0,
            'CAGR': 0.0,
            'Volatility': 0.0,
            'Sortino': 0.0,
            'Expectancy': 0.0
        }
