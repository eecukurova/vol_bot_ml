"""Backtesting module."""

from .quick_sim import QuickSimulator

__all__ = ["QuickSimulator"]

