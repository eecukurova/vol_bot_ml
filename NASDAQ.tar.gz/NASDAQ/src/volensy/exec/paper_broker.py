"""Paper broker for order/trade execution (v1.2)."""

import uuid
import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import Literal
from dataclasses import dataclass
from loguru import logger
from ..config import config
from ..utils import safe_append_parquet, safe_to_parquet


@dataclass
class Order:
    """Order record."""
    ts: pd.Timestamp
    order_id: str
    symbol: str
    side: Literal["BUY", "SELL"]
    qty: int
    price: float
    cost: float
    slippage_bps: int
    commission_bps: int
    reason: str
    status: Literal["FILLED"] = "FILLED"


@dataclass
class Trade:
    """Trade record."""
    ts: pd.Timestamp
    trade_id: str
    order_id: str
    symbol: str
    side: Literal["BUY", "SELL"]
    qty: int
    price: float
    pnl: float | None = None
    reason: str = ""


class PaperBroker:
    """Simulates order execution with costs (v1.2)."""
    
    def __init__(self):
        """Initialize paper broker."""
        self.orders_path = Path(config.storage.orders_path)
        self.trades_path = Path(config.storage.trades_path)
    
    def create_order(self, symbol: str, side: str, qty: int, price: float, reason: str) -> str:
        """
        Create and fill order immediately (market fill).
        
        Args:
            symbol: Stock symbol
            side: "BUY" or "SELL"
            qty: Quantity
            price: Base price
            reason: Trade reason
        
        Returns:
            Order ID
        """
        order_id = str(uuid.uuid4())
        
        # Apply costs
        slippage = price * (config.bt.slippage_bps / 1e4)
        commission = price * (config.bt.commission_bps / 1e4)
        
        if side == "BUY":
            fill_price = price + slippage + commission
        else:  # SELL
            fill_price = price - slippage - commission
        
        cost = qty * abs(fill_price)
        
        # Create order record
        order_df = pd.DataFrame([{
            'ts': datetime.now(),
            'order_id': order_id,
            'symbol': symbol,
            'side': side,
            'qty': qty,
            'price': float(price),
            'fill_price': float(fill_price),
            'cost': float(cost),
            'slippage_bps': config.bt.slippage_bps,
            'commission_bps': config.bt.commission_bps,
            'reason': reason,
            'status': 'FILLED'
        }])
        
        safe_to_parquet(order_df, str(self.orders_path), append=True)
        
        # Create trade record
        trade_id = str(uuid.uuid4())
        trade_df = pd.DataFrame([{
            'ts': datetime.now(),
            'trade_id': trade_id,
            'order_id': order_id,
            'symbol': symbol,
            'side': side,
            'qty': qty,
            'price': float(fill_price),
            'pnl': None,
            'reason': reason
        }])
        
        safe_to_parquet(trade_df, str(self.trades_path), append=True)
        
        logger.info(f"Order {side} {qty} {symbol} @ ${fill_price:.2f} (reason: {reason})")
        
        return order_id
    
    def get_trades(self) -> pd.DataFrame:
        """Get all trades."""
        if self.trades_path.exists():
            return pd.read_parquet(self.trades_path)
        return pd.DataFrame()
    
    def get_orders(self) -> pd.DataFrame:
        """Get all orders."""
        if self.orders_path.exists():
            return pd.read_parquet(self.orders_path)
        return pd.DataFrame()

