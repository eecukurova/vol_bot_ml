"""Equity curve tracker (v1.2)."""

import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import Dict, List
from loguru import logger
from ..config import config
from ..utils import safe_read_json
from .position_tracker import PositionTracker


class EquityCurve:
    """Track equity over time (v1.2)."""
    
    def __init__(self, initial_cash: float = 100_000):
        """
        Initialize equity curve.
        
        Args:
            initial_cash: Starting cash
        """
        self.initial_cash = initial_cash
        self.cash = initial_cash
        self.equity_path = Path(config.storage.equity_path)
        self.curve: List[Dict] = []
        self.position_tracker = PositionTracker()
    
    def update(self, prices: Dict[str, float], cash: float):
        """
        Update equity with current prices.
        
        Args:
            prices: Dict of symbol -> current price
            cash: Current cash
        """
        positions_value = 0.0
        
        for symbol, qty_data in self.position_tracker.get_all_positions().items():
            qty = qty_data.get('qty', 0)
            if symbol in prices and qty > 0:
                positions_value += qty * prices[symbol]
        
        equity = cash + positions_value
        
        # Calculate drawdown
        if self.curve:
            peak = max([e['equity'] for e in self.curve])
            drawdown = (equity / peak - 1.0) if peak > 0 else 0.0
        else:
            drawdown = 0.0
        
        self.curve.append({
            'date': datetime.now(),
            'equity': equity,
            'cash': cash,
            'positions_value': positions_value,
            'drawdown': drawdown
        })
        
        self.cash = cash
    
    def save(self):
        """Save equity curve to CSV."""
        if not self.curve:
            return
        
        df = pd.DataFrame(self.curve)
        df.to_csv(self.equity_path, index=False)
        logger.info(f"Equity curve saved: {len(df)} points")
    
    def get_last_equity(self) -> float:
        """Get last equity value."""
        if self.curve:
            return self.curve[-1]['equity']
        return self.initial_cash

