"""Position tracker for open positions (v1.2.1 with latest_close)."""

import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, List
from loguru import logger
from ..config import config
from ..utils import safe_read_json, safe_write_json
from ..data_fetcher.yfinance_client import latest_close


class PositionTracker:
    """Track open positions (v1.2)."""
    
    def __init__(self):
        """Initialize position tracker."""
        self.positions_path = Path(config.storage.positions_path)
        self.positions = safe_read_json(str(self.positions_path), {})
    
    def get_position(self, symbol: str) -> Optional[Dict]:
        """Get position for symbol."""
        return self.positions.get(symbol)
    
    def apply_trade(self, trade: Dict):
        """
        Apply trade to positions.
        
        Args:
            trade: Trade dict with symbol, side, qty, price
        """
        symbol = trade['symbol']
        side = trade['side']
        qty = trade['qty']
        price = trade['price']
        
        if symbol not in self.positions:
            self.positions[symbol] = {'qty': 0, 'avg_price': 0.0, 'last_update': str(datetime.now())}
        
        pos = self.positions[symbol]
        
        if side == "BUY":
            total_cost = pos['qty'] * pos['avg_price'] + qty * price
            pos['qty'] += qty
            pos['avg_price'] = total_cost / pos['qty'] if pos['qty'] > 0 else 0.0
        elif side == "SELL":
            pos['qty'] -= qty
            if pos['qty'] < 0:
                logger.warning(f"Over-sold {symbol}")
                pos['qty'] = 0
            if pos['qty'] == 0:
                pos['avg_price'] = 0.0
        
        pos['last_update'] = str(datetime.now())
        self._save()
    
    def get_all_positions(self) -> Dict:
        """Get all positions."""
        return self.positions.copy()
    
    def close_all(self) -> List[Dict]:
        """
        Close all positions using latest close prices (v1.2.1).
        
        Returns:
            List of close trades
        """
        close_trades = []
        
        for symbol, pos in self.positions.items():
            if pos['qty'] > 0:
                # Try to get latest close
                current_price = latest_close(symbol)
                
                # Fallback to avg_price if latest_close fails
                if current_price is None:
                    current_price = pos.get('avg_price', 0.0)
                    logger.warning(f"Using avg_price for {symbol}: {current_price}")
                
                close_trades.append({
                    'symbol': symbol,
                    'side': 'SELL',
                    'qty': pos['qty'],
                    'price': current_price,
                    'reason': 'close_all'
                })
        
        self.positions = {}
        self._save()
        
        logger.info(f"Closed all {len(close_trades)} positions")
        return close_trades
    
    def _save(self):
        """Save positions to JSON."""
        safe_write_json(self.positions, str(self.positions_path))

