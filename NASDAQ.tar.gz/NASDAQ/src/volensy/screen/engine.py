"""
Screening engine (v1.2.1 with signal logging integration).
"""

import json
import pandas as pd
import numpy as np
from typing import Dict, List
from pathlib import Path
from loguru import logger
from ..config import config
from ..scoring.scorer import compute_scores
from ..signals import (
    detect_ema_trend,
    detect_rsi_rebound,
    detect_volume_spike,
    detect_donchian_breakout,
    detect_52w_setup
)
from ..signals.types import SignalResult
from ..utils import safe_append_parquet, rotate_if_big


def _append_signal_log(symbol: str, df: pd.DataFrame, snap_row: pd.Series, data: Dict[str, pd.DataFrame]) -> None:
    """
    Append signal snapshot to storage/signals.parquet (v1.2.1).
    
    Args:
        symbol: Stock symbol
        df: Full OHLCV DataFrame
        snap_row: Single row from results DataFrame
        data: Full data dictionary
    """
    try:
        # Check if signals path is configured
        if not hasattr(config, 'storage') or not config.storage.signals_path:
            return
        
        # Rotate if big
        rotate_if_big(config.storage.signals_path, config.storage.rotation_max_mb, config.storage.rotation_keep)
        
        # Get timestamp
        ts = df.index[-1].isoformat() if len(df.index) > 0 else pd.Timestamp.now().isoformat()
        
        # Calculate indicators from original data
        from ..indicators import calculate_rsi, calculate_ema, calculate_atr, calculate_donchian
        
        rsi_vals = calculate_rsi(df['close'], 14) if 'close' in df.columns else pd.Series()
        ema50_vals = calculate_ema(df['close'], 50) if 'close' in df.columns else pd.Series()
        ema200_vals = calculate_ema(df['close'], 200) if 'close' in df.columns else pd.Series()
        atr_vals = calculate_atr(df['high'], df['low'], df['close'], 14) if all(c in df.columns for c in ['high', 'low', 'close']) else pd.Series()
        
        donchian_up, _, donchian_down = calculate_donchian(df['high'], df['low'], 20) if all(c in df.columns for c in ['high', 'low']) else (pd.Series(), pd.Series(), pd.Series())
        
        # Create log entry
        log_row = {
            "ts": ts,
            "symbol": symbol,
            "close": float(df['close'].iloc[-1]) if len(df) > 0 else 0.0,
            "rsi": float(rsi_vals.iloc[-1]) if len(rsi_vals) > 0 else None,
            "ema50": float(ema50_vals.iloc[-1]) if len(ema50_vals) > 0 else None,
            "ema200": float(ema200_vals.iloc[-1]) if len(ema200_vals) > 0 else None,
            "atr14": float(atr_vals.iloc[-1]) if len(atr_vals) > 0 else None,
            "donchian_h": float(donchian_up.iloc[-1]) if len(donchian_up) > 0 else None,
            "donchian_l": float(donchian_down.iloc[-1]) if len(donchian_down) > 0 else None,
            "fired_signals": json.dumps(snap_row.get('fired_signals', []), ensure_ascii=False) if isinstance(snap_row.get('fired_signals'), list) else str(snap_row.get('fired_signals', '')),
            "explanations": str(snap_row.get('explanations', '')),
            "score": float(snap_row.get('score', 0)),
            "score_breakdown": json.dumps(snap_row.get('score_breakdown', {}), ensure_ascii=False) if isinstance(snap_row.get('score_breakdown'), dict) else str(snap_row.get('score_breakdown', '{}'))
        }
        
        # Append to parquet
        log_df = pd.DataFrame([log_row])
        safe_append_parquet(log_df, config.storage.signals_path)
        
        logger.debug(f"Logged signal for {symbol}")
    
    except Exception as e:
        logger.error(f"Failed to log signal for {symbol}: {e}")


def _combine_explanations(sig_map: Dict[str, SignalResult]) -> pd.Series:
    """Combine explanations from multiple signals."""
    parts = []
    for name, res in sig_map.items():
        # Only take explanations where signal fired
        parts.append(res.explanation.where(res.fired, other=np.nan))
    
    cat = pd.concat(parts, axis=1)
    return cat.apply(lambda row: ", ".join([x for x in row.dropna().astype(str) if x]), axis=1)


def _fired_list(sig_map: Dict[str, SignalResult], index: pd.Index) -> pd.Series:
    """Get list of fired signals for each timestamp."""
    fired_dfs = {name: res.fired for name, res in sig_map.items()}
    fired_df = pd.DataFrame(fired_dfs)
    
    fired_lists = fired_df.apply(
        lambda row: [name for name, fired in row.items() if fired],
        axis=1
    )
    
    return fired_lists


class ScreenEngine:
    """Engine for screening stocks (v1.1 enhanced)."""
    
    def __init__(self):
        """Initialize screen engine."""
        pass
    
    def screen(self, data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """
        Screen stocks and calculate scores with v1.1 enhancements.
        
        Args:
            data: Dict of symbol -> DataFrame
        
        Returns:
            DataFrame with top candidates including explanations, age, breakdown
        """
        results = []
        
        for symbol, df in data.items():
            if df.empty or len(df) < 50:
                continue
            
            try:
                row = self._screen_single_symbol(symbol, df)
                if row is not None:
                    results.append(row)
            except Exception as e:
                logger.error(f"Error screening {symbol}: {e}")
                continue
        
        if not results:
            return pd.DataFrame()
        
        # Create DataFrame and sort by score
        results_df = pd.DataFrame(results)
        results_df = results_df.sort_values('score', ascending=False)
        
        # Filter by minimum score
        results_df = results_df[results_df['score'] >= config.min_score]
        
        # Apply age filter if enabled
        if config.screen.max_age_days is not None:
            mask = results_df['last_signal_age'].notna() & (results_df['last_signal_age'] > config.screen.max_age_days)
            results_df.loc[mask, 'score'] = results_df.loc[mask, 'score'] * 0.5
            logger.info(f"Applied age penalty to {mask.sum()} symbols")
        
        # Return top N
        top_n = config.top_n if len(results_df) > config.top_n else len(results_df)
        out_df = results_df.head(top_n).copy()
        
        # v1.2.1: Log signals to storage/signals.parquet
        for idx, row in out_df.iterrows():
            symbol = row['symbol']
            if symbol in data:
                df = data[symbol]
                try:
                    _append_signal_log(symbol, df, row, data)
                except Exception as e:
                    logger.error(f"Failed to log signal for {symbol}: {e}")
        
        return out_df
    
    def _screen_single_symbol(self, symbol: str, df: pd.DataFrame) -> Dict:
        """Screen a single symbol and return enhanced result."""
        # Generate signals
        signals = self._generate_signals(df)
        
        # Check if any signal fired on the last bar
        snap_idx = df.index[-1]
        fired_now = {name: sig.fired.iloc[-1] if len(sig.fired) > 0 else False 
                     for name, sig in signals.items()}
        
        # Calculate signal ages
        last_fired_idx = {}
        for name, sig in signals.items():
            fired_bars = sig.fired[sig.fired]
            if len(fired_bars) > 0:
                last_fired_idx[name] = fired_bars.index[-1]
        
        # Get latest signal date
        if last_fired_idx:
            last_signal_date = max(last_fired_idx.values())
            last_signal_age = (pd.Timestamp(snap_idx) - last_signal_date).days
        else:
            last_signal_date = pd.NaT
            last_signal_age = None
        
        # Calculate scores
        strength_map = {name: sig.strength for name, sig in signals.items()}
        technical, momentum, volume, total, breakdown = compute_scores(
            df, fired_now, strength_map
        )
        
        # Combine explanations
        explanations = _combine_explanations(signals)
        explanation_str = explanations.iloc[-1] if len(explanations) else ""
        
        # Fired signals list
        fired_signals_list = [name for name, fired in fired_now.items() if fired]
        
        # Get latest price info
        latest_close = df['close'].iloc[-1]
        latest_volume = df['volume'].iloc[-1]
        
        return {
            'symbol': symbol,
            'close': latest_close,
            'volume': latest_volume,
            'technical_score': technical,
            'momentum_score': momentum,
            'volume_score': volume,
            'score': total,
            'fired_signals': json.dumps(fired_signals_list, ensure_ascii=False),
            'explanations': explanation_str,
            'last_signal_date': last_signal_date,
            'last_signal_age': last_signal_age,
            'score_breakdown': json.dumps(breakdown, ensure_ascii=False),
            'date': df.index[-1]
        }
    
    def _generate_signals(self, df: pd.DataFrame) -> Dict[str, SignalResult]:
        """Generate all signals for a DataFrame."""
        signals = {}
        
        try:
            if config.signals_config.ema_trend:
                signals['ema_trend'] = detect_ema_trend(df, config.ema_short, config.ema_long)
            
            if config.signals_config.rsi_rebound:
                signals['rsi_rebound'] = detect_rsi_rebound(df, config.rsi_period)
            
            if config.signals_config.volume_spike:
                signals['volume_spike'] = detect_volume_spike(df, config.volume_ma_period)
            
            if config.signals_config.donchian_breakout:
                signals['donchian_breakout'] = detect_donchian_breakout(df, config.donchian_period)
            
            if config.signals_config.hi52_setup:
                signals['hi52_setup'] = detect_52w_setup(df)
        
        except Exception as e:
            logger.error(f"Error generating signals: {e}")
        
        return signals
