"""
CLI entry point using Typer (v1.1 with universe selection and enhanced flags).
"""

import typer
from datetime import datetime, timedelta
from typing import List, Optional
from pathlib import Path
from loguru import logger
from rich.console import Console
from rich.table import Table

from .config import config
from .logging import setup_logging
from .data_fetcher import load_symbols, load_multiple_stocks
from .screen import ScreenEngine
from .backtest import QuickSimulator
from .export import export_to_csv, export_to_html
from .notify import send_top_stocks

app = typer.Typer()
console = Console()


def _get_universe_symbols(universe: str) -> List[str]:
    """Get symbols from universe selection."""
    if universe.startswith("file:"):
        # Load from file
        filepath = Path(universe.split("file:")[1].strip())
        if filepath.exists():
            import pandas as pd
            df = pd.read_csv(filepath)
            return df['symbol'].tolist() if 'symbol' in df.columns else []
        else:
            logger.warning(f"File not found: {filepath}")
            return []
    elif universe == "nasdaq100":
        # NASDAQ-100 symbols (sample)
        return load_symbols()  # Return all from symbols.csv
    else:
        # Default to symbols.csv
        return load_symbols()


@app.command()
def fetch(
    start: str = typer.Option(None, help="Start date (YYYY-MM-DD)"),
    end: str = typer.Option(None, help="End date (YYYY-MM-DD)"),
    universe: str = typer.Option("file:src/volensy/data/symbols.csv", help="Universe: 'nasdaq100' or 'file:path/to/symbols.csv'"),
):
    """Fetch stock data for symbols."""
    logger.info("Starting data fetch...")
    
    # Use defaults if not provided
    if not end:
        end = datetime.now().strftime("%Y-%m-%d")
    if not start:
        start = (datetime.now() - timedelta(days=180)).strftime("%Y-%m-%d")
    
    symbols = _get_universe_symbols(universe)
    logger.info(f"Loaded {len(symbols)} symbols from {universe}")
    
    data = load_multiple_stocks(symbols, start, end)
    logger.info(f"Fetched data for {len(data)} symbols")
    
    console.print(f"[green]✓ Fetched data for {len(data)} symbols[/green]")


@app.command()
def screen(
    top: int = typer.Option(25, help="Number of top stocks to return"),
    export: str = typer.Option("csv,html", help="Export formats (comma-separated)"),
    universe: str = typer.Option("file:src/volensy/data/symbols.csv", help="Universe: 'nasdaq100' or 'file:path/to/symbols.csv'"),
    include_explanations: bool = typer.Option(True, help="Include signal explanations in output"),
    lookback_days: int = typer.Option(None, help="Override lookback days"),
):
    """Screen stocks and return top candidates (v1.1)."""
    logger.info("Starting screening (v1.1)...")
    
    # Load data
    symbols = _get_universe_symbols(universe)
    end = datetime.now().strftime("%Y-%m-%d")
    lookback = lookback_days if lookback_days else config.backtest_lookback_days
    start = (datetime.now() - timedelta(days=lookback)).strftime("%Y-%m-%d")
    
    data = load_multiple_stocks(symbols, start, end)
    
    # Screen
    engine = ScreenEngine()
    results = engine.screen(data)
    
    if results.empty:
        console.print("[red]No results found[/red]")
        return
    
    # Display results
    table = Table(title=f"Top NASDAQ Stocks (v1.1)")
    table.add_column("Rank", style="cyan")
    table.add_column("Symbol", style="green")
    table.add_column("Score", style="yellow")
    table.add_column("Close", style="blue")
    if include_explanations:
        table.add_column("Signals", style="magenta")
        table.add_column("Age", style="white")
    
    for i, (_, row) in enumerate(results.head(top).iterrows(), 1):
        signals_str = row.get('fired_signals', 'None')[:30] + "..." if len(str(row.get('fired_signals', 'None'))) > 30 else row.get('fired_signals', 'None')
        age_str = f"{row.get('last_signal_age', 'N/A')}" if row.get('last_signal_age') is not None else 'N/A'
        
        row_data = [
            str(i),
            row['symbol'],
            f"{row['score']:.1f}",
            f"${row['close']:.2f}"
        ]
        
        if include_explanations:
            row_data.extend([signals_str, age_str])
        
        table.add_row(*row_data)
    
    console.print(table)
    
    # Export
    export_formats = [fmt.strip() for fmt in export.split(",")]
    exported_paths = []
    
    if "csv" in export_formats:
        path = export_to_csv(results, "screen")
        exported_paths.append(path)
        console.print(f"[green]✓ CSV: {path}[/green]")
    
    if "html" in export_formats:
        path = export_to_html(results, "screen")
        exported_paths.append(path)
        console.print(f"[green]✓ HTML: {path}[/green]")
    
    # Notify via Telegram
    if config.notify_telegram:
        stock_dicts = results.to_dict('records')
        send_top_stocks(stock_dicts, top)
    
    # Print output paths
    if exported_paths:
        console.print("\n[bold]Exported to:[/bold]")
        for path in exported_paths:
            console.print(f"  {path}")


@app.command()
def backtest(
    lookback_days: int = typer.Option(180, help="Lookback period in days"),
    slippage_bps: int = typer.Option(5, help="Slippage in basis points"),
    commission_bps: int = typer.Option(5, help="Commission in basis points"),
    position_sizing: str = typer.Option("fixed_cash", help="Position sizing: 'fixed_cash' or 'fixed_pct'"),
    fixed_cash_usd: float = typer.Option(100.0, help="Fixed cash per trade (USD)"),
    fixed_pct: float = typer.Option(1.0, help="Fixed percentage of equity per trade"),
    initial_equity: float = typer.Option(100_000, help="Initial equity"),
    universe: str = typer.Option("file:src/volensy/data/symbols.csv", help="Universe: 'nasdaq100' or 'file:path/to/symbols.csv'"),
):
    """Run backtest on historical data (v1.1 with costs, sizing, and enhanced metrics)."""
    logger.info("Starting backtest (v1.1)...")
    
    # Override config temporarily
    config.bt.slippage_bps = slippage_bps
    config.bt.commission_bps = commission_bps
    config.bt.position_sizing = position_sizing
    config.bt.fixed_cash_usd = fixed_cash_usd
    config.bt.fixed_pct = fixed_pct
    
    # Load data
    symbols = _get_universe_symbols(universe)
    end = datetime.now().strftime("%Y-%m-%d")
    start = (datetime.now() - timedelta(days=lookback_days)).strftime("%Y-%m-%d")
    
    data = load_multiple_stocks(symbols, start, end)
    
    # Run backtest
    simulator = QuickSimulator()
    metrics = simulator.backtest(data, initial_equity)
    
    # Display results
    table = Table(title="Backtest Results (v1.1)")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")
    
    table.add_row("Total Trades", str(metrics.get('total_trades', 0)))
    table.add_row("Win Rate", f"{metrics.get('WinRate', 0) * 100:.2f}%")
    table.add_row("Profit Factor", f"{metrics.get('profit_factor', 0):.2f}")
    table.add_row("Sharpe Ratio", f"{metrics.get('Sharpe', 0):.2f}")
    table.add_row("Sortino Ratio", f"{metrics.get('Sortino', 0):.2f}")
    table.add_row("Max Drawdown", f"{metrics.get('MaxDrawdown', 0):.4f}")
    table.add_row("CAGR", f"{metrics.get('CAGR', 0) * 100:.2f}%")
    table.add_row("Volatility", f"{metrics.get('Volatility', 0) * 100:.2f}%")
    
    console.print(table)
    
    # Check for metrics.json
    metrics_file = config.output_dir / "metrics.json"
    if metrics_file.exists():
        console.print(f"\n[green]✓ Metrics written to: {metrics_file}[/green]")


@app.command()
def notify(
    top: int = typer.Option(10, help="Number of top stocks to notify"),
):
    """Send top stocks to Telegram."""
    logger.info("Sending notifications...")
    
    console.print("[yellow]Note: Run 'screen' command first to generate results[/yellow]")


@app.command()
def run(
    universe: str = typer.Option("file:src/volensy/data/symbols.csv", help="Universe selection"),
    top: int = typer.Option(10, help="Top N stocks to consider"),
    entry: str = typer.Option("score>=80", help="Entry condition"),
    exit_cond: str = typer.Option("score<70", help="Exit condition"),
    initial_cash: float = typer.Option(100_000, help="Initial cash"),
):
    """Run paper trading simulation (v1.2)."""
    from ..exec import PaperBroker, PositionTracker, EquityCurve
    
    logger.info("Starting paper trading run (v1.2)...")
    
    # Setup
    broker = PaperBroker()
    positions = PositionTracker()
    equity = EquityCurve(initial_cash)
    
    # Fetch data
    symbols = _get_universe_symbols(universe)
    end = datetime.now().strftime("%Y-%m-%d")
    start = (datetime.now() - timedelta(days=config.backtest_lookback_days)).strftime("%Y-%m-%d")
    
    data = load_multiple_stocks(symbols, start, end)
    
    # Screen
    engine = ScreenEngine()
    results = engine.screen(data)
    
    if results.empty:
        console.print("[red]No results found[/red]")
        return
    
    # Simple entry/exit logic
    cash = initial_cash
    
    for symbol in results['symbol'].head(top):
        if symbol not in data:
            continue
        
        df = data[symbol]
        if df.empty:
            continue
        
        score = results[results['symbol'] == symbol]['score'].iloc[0]
        current_price = df['close'].iloc[-1]
        
        # Entry logic
        if eval(entry.replace('score', str(score))):
            if not positions.get_position(symbol) or positions.get_position(symbol)['qty'] == 0:
                qty = int(initial_cash / 10 / current_price)
                if qty > 0 and qty * current_price <= cash:
                    broker.create_order(symbol, "BUY", qty, current_price, f"entry:score={score:.0f}")
                    positions.apply_trade({
                        'symbol': symbol,
                        'side': 'BUY',
                        'qty': qty,
                        'price': current_price
                    })
                    cash -= qty * current_price
        
        # Exit logic
        elif positions.get_position(symbol) and positions.get_position(symbol)['qty'] > 0:
            if eval(exit_cond.replace('score', str(score))):
                pos = positions.get_position(symbol)
                broker.create_order(symbol, "SELL", pos['qty'], current_price, f"exit:score={score:.0f}")
                positions.apply_trade({
                    'symbol': symbol,
                    'side': 'SELL',
                    'qty': pos['qty'],
                    'price': current_price
                })
                cash += pos['qty'] * current_price
    
    # Update equity
    current_prices = {sym: df['close'].iloc[-1] for sym, df in data.items()}
    equity.update(current_prices, cash)
    equity.save()
    
    # Display results
    console.print(f"[green]✓ Paper run complete[/green]")
    console.print(f"  Orders: {len(broker.get_orders())}")
    console.print(f"  Trades: {len(broker.get_trades())}")
    console.print(f"  Equity: ${equity.get_last_equity():,.2f}")
    console.print(f"\n  Storage files updated:")
    console.print(f"    - {broker.orders_path}")
    console.print(f"    - {broker.trades_path}")
    console.print(f"    - {Path(config.storage.positions_path)}")
    console.print(f"    - {equity.equity_path}")


@app.command()
def positions():
    """Show current positions (v1.2)."""
    from ..exec import PositionTracker
    from rich.table import Table
    
    pos_tracker = PositionTracker()
    all_pos = pos_tracker.get_all_positions()
    
    if not all_pos or not any(p.get('qty', 0) > 0 for p in all_pos.values()):
        console.print("[yellow]No open positions[/yellow]")
        return
    
    table = Table(title="Open Positions (v1.2)")
    table.add_column("Symbol", style="cyan")
    table.add_column("Qty", style="green")
    table.add_column("Avg Price", style="yellow")
    table.add_column("Last Update", style="blue")
    
    for symbol, pos in all_pos.items():
        if pos.get('qty', 0) > 0:
            table.add_row(
                symbol,
                str(pos['qty']),
                f"${pos['avg_price']:.2f}",
                pos['last_update']
            )
    
    console.print(table)


@app.command()
def close_all():
    """Close all positions (v1.2.1)."""
    from ..exec.position_tracker import PositionTracker
    from ..exec.equity_curve import EquityCurve
    from ..exec.paper_broker import PaperBroker
    
    pos_tracker = PositionTracker()
    equity_curve = EquityCurve()
    broker = PaperBroker()
    
    # Get current positions
    all_pos = pos_tracker.get_all_positions()
    open_count = len([p for p in all_pos.values() if p.get('qty', 0) > 0])
    
    if open_count == 0:
        console.print("[yellow]No open positions to close[/yellow]")
        return
    
    # Close all positions (v1.2.1 uses latest_close)
    close_trades = pos_tracker.close_all()
    
    if not close_trades:
        console.print("[yellow]No positions were closed[/yellow]")
        return
    
    # Record trades
    for trade in close_trades:
        broker.record_trade({
            'timestamp': datetime.now().isoformat(),
            **trade
        })
    
    # Update equity
    equity_curve.update_equity(datetime.now(), sum(t['qty'] * t['price'] for t in close_trades))
    
    console.print(f"[green]✓ Closed {len(close_trades)} positions[/green]")
    console.print(f"[cyan]Updated equity at {config.storage.equity_path}[/cyan]")


@app.command()
def report(top: int = typer.Option(20, help="Number of top stocks to include")):
    """Generate daily HTML report (v1.2.1)."""
    from ..export.daily_report import build_daily_report
    
    output_path = build_daily_report(top=top)
    
    if output_path:
        console.print(f"[green]✓ Report generated: {output_path}[/green]")
        console.print(f"[cyan]Open: open {output_path}[/cyan]")
    else:
        console.print("[yellow]Report generation failed[/yellow]")


@app.command()
def dataset(
    start: str = typer.Option(None, help="Start date"),
    end: str = typer.Option(None, help="End date"),
    horizons: str = typer.Option("5,10", help="Forward horizons (comma-separated)"),
    thresholds: str = typer.Option("0.01,0.02", help="Return thresholds (comma-separated)"),
):
    """Build ML dataset (v1.2)."""
    from ..ml import build_dataset
    
    if not start:
        start = (datetime.now() - timedelta(days=180)).strftime("%Y-%m-%d")
    if not end:
        end = datetime.now().strftime("%Y-%m-%d")
    
    horizons_list = [int(h) for h in horizons.split(",")]
    thresholds_list = [float(t) for t in thresholds.split(",")]
    
    # Load symbols (limit to 10 for testing)
    symbols = load_symbols()[:10]
    
    logger.info(f"Building dataset for {len(symbols)} symbols")
    
    output_path = build_dataset(symbols, start, end, horizons_list, thresholds_list)
    
    if output_path:
        console.print(f"[green]✓ Dataset saved: {output_path}[/green]")
        console.print(f"[cyan]  Columns: {output_path.stem}[/cyan]")
        
        # Health check (v1.2.1)
        from ..utils import check_dataset_health
        health = check_dataset_health(str(output_path))
        
        if health['is_healthy']:
            console.print(f"[green]  Health: OK (rows={health['rows']}, nan={health['nan_count']}, inf={health['inf_count']})[/green]")
        else:
            console.print(f"[yellow]  Health: ⚠️  nan={health['nan_count']}, inf={health['inf_count']}[/yellow]")
    else:
        console.print("[yellow]Note: Run 'screen' first to generate signal data[/yellow]")
        console.print("[yellow]  or use fetch with longer date range[/yellow]")


if __name__ == "__main__":
    setup_logging("INFO")
    app()
