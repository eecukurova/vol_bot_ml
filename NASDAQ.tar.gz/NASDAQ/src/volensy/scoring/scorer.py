"""
Scoring engine (v1.1 with breakdown and bear trend handling).
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple
from ..config import config


def _clip01(x: float) -> float:
    """Clip value to [0, 1] range."""
    return max(0.0, min(1.0, float(x)))


def compute_scores(df: pd.DataFrame, fired_now: Dict[str, bool], strength_map: Dict[str, pd.Series]) -> Tuple[float, float, float, float, dict]:
    """
    Compute composite scores with breakdown (v1.1).
    
    Args:
        df: OHLCV DataFrame
        fired_now: Dict of signal name -> bool (fired at current bar)
        strength_map: Dict of signal name -> Series (strength values)
    
    Returns:
        Tuple of (technical_score, momentum_score, volume_score, total_score, breakdown_dict)
    """
    cfg = config
    w = cfg.weights if hasattr(cfg, 'weights') else {
        "technical": 0.6,
        "momentum": 0.2,
        "volume": 0.2
    }
    
    # Extract current strength values
    ema_val = 1.0 if fired_now.get("ema_trend") else 0.0
    rsi_val = _clip01(strength_map.get("rsi_rebound", pd.Series([0.0])).iloc[-1] if "rsi_rebound" in strength_map and len(strength_map["rsi_rebound"]) > 0 else 0.0)
    vol_val = _clip01(strength_map.get("volume_spike", pd.Series([0.0])).iloc[-1] if "volume_spike" in strength_map and len(strength_map["volume_spike"]) > 0 else 0.0)
    don_val = 1.0 if fired_now.get("donchian_breakout") else 0.0
    hi52_val = _clip01(strength_map.get("hi52_setup", pd.Series([0.0])).iloc[-1] if "hi52_setup" in strength_map and len(strength_map["hi52_setup"]) > 0 else 0.0)
    
    # Combine into component scores
    technical = _clip01(0.6 * ema_val + 0.4 * don_val)
    momentum = _clip01(0.7 * rsi_val + 0.3 * don_val)
    volume = _clip01(vol_val)
    
    # Bear trend penalty (optional)
    if not fired_now.get("ema_trend", False):
        technical *= 0.5
    
    # Calculate total score
    total = 100.0 * (w.technical * technical + w.momentum * momentum + w.volume * volume)
    
    breakdown = {
        "technical": round(100 * technical, 2),
        "momentum": round(100 * momentum, 2),
        "volume": round(100 * volume, 2),
        "weights": {
            "technical": w.technical,
            "momentum": w.momentum,
            "volume": w.volume
        },
        "signal_details": {
            "ema_trend": ema_val,
            "rsi_rebound": rsi_val,
            "volume_spike": vol_val,
            "donchian_breakout": don_val,
            "hi52_setup": hi52_val
        }
    }
    
    return (
        round(100 * technical, 2),
        round(100 * momentum, 2),
        round(100 * volume, 2),
        round(total, 2),
        breakdown
    )


class ScoreEngine:
    """Engine for calculating composite scores."""
    
    def __init__(self):
        """Initialize score engine."""
        pass
    
    def calculate_score(self, signals: Dict[str, pd.Series]) -> pd.Series:
        """
        Calculate composite score from signal strengths (legacy support).
        
        Args:
            signals: Dict of signal_name -> Series
        
        Returns:
            Composite score Series (0-100)
        """
        # Group signals by category
        technical_signals = ['ema_trend']
        momentum_signals = ['rsi_rebound', 'donchian_breakout', 'hi52_setup']
        volume_signals = ['volume_spike']
        
        scores = pd.DataFrame()
        
        # Technical score
        if technical_signals:
            tech_scores = []
            for sig in technical_signals:
                if sig in signals:
                    sig_values = signals[sig]
                    sig_values = (sig_values - sig_values.min()) / (sig_values.max() - sig_values.min() + 1e-8)
                    tech_scores.append(sig_values.fillna(0))
            
            if tech_scores:
                scores['technical'] = pd.concat(tech_scores, axis=1).mean(axis=1, skipna=True)
            else:
                scores['technical'] = 0.0
        
        # Momentum score
        if momentum_signals:
            mom_scores = []
            for sig in momentum_signals:
                if sig in signals:
                    sig_values = signals[sig]
                    sig_values = sig_values.clip(0, None)
                    sig_values = (sig_values - sig_values.min()) / (sig_values.max() - sig_values.min() + 1e-8)
                    mom_scores.append(sig_values.fillna(0))
            
            if mom_scores:
                scores['momentum'] = pd.concat(mom_scores, axis=1).mean(axis=1, skipna=True)
            else:
                scores['momentum'] = 0.0
        
        # Volume score
        if volume_signals:
            vol_scores = []
            for sig in volume_signals:
                if sig in signals:
                    sig_values = signals[sig]
                    sig_values = (sig_values - sig_values.min()) / (sig_values.max() - sig_values.min() + 1e-8)
                    vol_scores.append(sig_values.fillna(0))
            
            if vol_scores:
                scores['volume'] = pd.concat(vol_scores, axis=1).mean(axis=1, skipna=True)
            else:
                scores['volume'] = 0.0
        
        # Calculate composite score
        weights = config.weights
        composite = (
            scores['technical'] * weights.technical +
            scores['momentum'] * weights.momentum +
            scores['volume'] * weights.volume
        ) * 100
        
        return composite
    
    def explain_score(self, signals: Dict[str, pd.Series], row_idx: int) -> Dict:
        """
        Explain score for a specific row.
        
        Args:
            signals: Dict of signals
            row_idx: Row index to explain
        
        Returns:
            Dict with score breakdown
        """
        breakdown = {}
        
        for signal_name, signal_series in signals.items():
            if row_idx < len(signal_series):
                breakdown[signal_name] = float(signal_series.iloc[row_idx])
        
        return breakdown
