"""
Donchian breakout signal detection (v1.1).
"""

import pandas as pd
import numpy as np
from ..indicators import calculate_donchian
from .types import SignalResult


def detect_donchian_breakout(df: pd.DataFrame, period: int = 20) -> SignalResult:
    """
    Detect Donchian channel breakout (v1.1 with separate explanations).
    
    Signal: Price breaks above upper band (bull) or below lower band (bear)
    
    Args:
        df: OHLCV DataFrame
        period: Donchian period
    
    Returns:
        SignalResult with fired, strength, and explanation
    """
    if df.empty or 'high' not in df.columns or 'low' not in df.columns or 'close' not in df.columns:
        empty_series = pd.Series([False] * len(df), index=df.index)
        empty_explanations = pd.Series([""] * len(df), index=df.index)
        return SignalResult(
            fired=empty_series,
            strength=pd.Series([0.0] * len(df), index=df.index),
            explanation=empty_explanations
        )
    
    upper, _, lower = calculate_donchian(df['high'], df['low'], period)
    
    # Breakout detection
    upper_breakout = (df['close'] > upper.shift(1)) & (df['close'].shift(1) <= upper.shift(1))
    lower_breakout = (df['close'] < lower.shift(1)) & (df['close'].shift(1) >= lower.shift(1))
    
    signal_strength = np.where(
        upper_breakout,
        0.3,  # Bull breakout
        np.where(
            lower_breakout,
            -0.1,  # Bear breakout (negative)
            0.0   # No breakout
        )
    )
    
    fired = signal_strength != 0
    
    # Generate separate explanations for upper/lower
    explanations = pd.Series([
        f"Donchian {period}d upper breakout" if upper_b 
        else f"Donchian {period}d lower breakout" if lower_b
        else ""
        for upper_b, lower_b in zip(upper_breakout, lower_breakout)
    ], index=df.index)
    
    return SignalResult(
        fired=pd.Series(fired, index=df.index),
        strength=pd.Series(signal_strength, index=df.index),
        explanation=explanations
    )
