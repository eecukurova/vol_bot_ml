"""
RSI rebound signal detection (v1.1).
"""

import pandas as pd
import numpy as np
from ..indicators import calculate_rsi
from .types import SignalResult


def detect_rsi_rebound(df: pd.DataFrame, rsi_period: int = 14, oversold: float = 30, neutral: float = 50) -> SignalResult:
    """
    Detect RSI rebound signal.
    
    Signal: RSI < oversold threshold and then rises above oversold
    
    Args:
        df: OHLCV DataFrame
        rsi_period: RSI period
        oversold: Oversold threshold
        neutral: Neutral threshold
    
    Returns:
        SignalResult with fired, strength, and explanation
    """
    if df.empty or 'close' not in df.columns:
        empty_series = pd.Series([False] * len(df), index=df.index)
        empty_explanations = pd.Series([""] * len(df), index=df.index)
        return SignalResult(
            fired=empty_series,
            strength=pd.Series([0.0] * len(df), index=df.index),
            explanation=empty_explanations
        )
    
    rsi = calculate_rsi(df['close'], rsi_period)
    
    # Rebound signal: RSI was oversold and now rising
    was_oversold = (rsi.shift(1) < oversold) & (rsi > oversold)
    rising = (rsi > rsi.shift(1)) & (rsi < neutral)
    
    signal_strength = np.where(
        was_oversold & rising,
        0.8,  # Strong rebound
        np.where(
            rsi < oversold,
            0.3,  # Oversold zone
            0.0   # No signal
        )
    )
    
    fired = signal_strength > 0
    
    # Generate explanations
    explanations = pd.Series([
        f"RSI rebound >{oversold:.0f} on {date.date()}" if fired_ 
        else f"RSI oversold <{oversold:.0f}" if strength < 0.5 and strength > 0
        else ""
        for fired_, strength, date in zip(fired, signal_strength, df.index)
    ], index=df.index)
    
    return SignalResult(
        fired=pd.Series(fired, index=df.index),
        strength=pd.Series(signal_strength, index=df.index),
        explanation=explanations
    )
