"""
Volume spike signal detection (v1.1).
"""

import pandas as pd
import numpy as np
from ..indicators import calculate_volume_ma
from .types import SignalResult


def detect_volume_spike(df: pd.DataFrame, period: int = 20, multiplier: float = 1.5) -> SignalResult:
    """
    Detect volume spike signal (v1.1 with gradations).
    
    Signal: Current volume > multiplier × average volume
    
    Args:
        df: OHLCV DataFrame
        period: Volume MA period
        multiplier: Spike threshold (default 1.5)
    
    Returns:
        SignalResult with fired, strength (0.5 for 1.5x, 1.0 for 2.0x), and explanation
    """
    if df.empty or 'volume' not in df.columns:
        empty_series = pd.Series([False] * len(df), index=df.index)
        empty_explanations = pd.Series([""] * len(df), index=df.index)
        return SignalResult(
            fired=empty_series,
            strength=pd.Series([0.0] * len(df), index=df.index),
            explanation=empty_explanations
        )
    
    volume_ma = calculate_volume_ma(df['volume'], period)
    
    # Volume spike detection with gradations
    volume_ratio = df['volume'] / volume_ma
    
    # Strength: 0.5 for 1.5x, 1.0 for 2.0x+
    signal_strength = np.where(
        volume_ratio > multiplier * 2,
        1.0,  # Strong spike (2x+)
        np.where(
            volume_ratio > multiplier,
            0.5,  # Moderate spike (1.5x)
            0.0   # No spike
        )
    )
    
    fired = signal_strength > 0
    
    explanations = pd.Series([
        f"Vol spike {ratio:.1f}x avg on {date.date()}" if fired_ 
        else ""
        for fired_, ratio, date in zip(fired, volume_ratio, df.index)
    ], index=df.index)
    
    return SignalResult(
        fired=pd.Series(fired, index=df.index),
        strength=pd.Series(signal_strength, index=df.index),
        explanation=explanations
    )
