"""
EMA trend signal detection (v1.1).
"""

import pandas as pd
import numpy as np
from ..indicators import calculate_ema
from .types import SignalResult


def detect_ema_trend(df: pd.DataFrame, ema_short: int = 50, ema_long: int = 200) -> SignalResult:
    """
    Detect EMA trend signal.
    
    Bull signal: EMA_short > EMA_long
    Bear signal: EMA_short < EMA_long
    
    Args:
        df: OHLCV DataFrame
        ema_short: Short EMA period
        ema_long: Long EMA period
    
    Returns:
        SignalResult with fired, strength, and explanation
    """
    if df.empty or 'close' not in df.columns:
        empty_series = pd.Series([False] * len(df), index=df.index)
        empty_explanations = pd.Series([""] * len(df), index=df.index)
        return SignalResult(
            fired=empty_series,
            strength=pd.Series([0.0] * len(df), index=df.index),
            explanation=empty_explanations
        )
    
    ema_short_series = calculate_ema(df['close'], ema_short)
    ema_long_series = calculate_ema(df['close'], ema_long)
    
    # Signal strength based on EMA crossover
    is_bull = ema_short_series > ema_long_series
    signal_strength = np.where(is_bull, 1.0, -1.0)
    
    # Generate explanations
    explanations = pd.Series([
        f"EMA{ema_short}/{ema_long} {'Bull' if bull else 'Bear'}" 
        for bull in is_bull
    ], index=df.index)
    
    # Signal fired when there's a trend (bull or bear)
    fired = pd.Series([True] * len(df), index=df.index)
    
    return SignalResult(
        fired=fired,
        strength=pd.Series(signal_strength, index=df.index),
        explanation=explanations
    )

