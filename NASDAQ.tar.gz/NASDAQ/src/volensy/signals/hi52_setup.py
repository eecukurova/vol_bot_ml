"""
52-week high/low setup signal detection (v1.1).
"""

import pandas as pd
import numpy as np
from ..indicators import calculate_52w_high_low
from .types import SignalResult


def detect_52w_setup(df: pd.DataFrame) -> SignalResult:
    """
    Detect 52-week high/low setup with distance metrics.
    
    Signal: Price position relative to 52w range
    
    Args:
        df: OHLCV DataFrame
    
    Returns:
        SignalResult with fired, strength (positive near high, negative near low), and explanation
    """
    if df.empty or 'high' not in df.columns or 'low' not in df.columns or 'close' not in df.columns:
        empty_series = pd.Series([False] * len(df), index=df.index)
        empty_explanations = pd.Series([""] * len(df), index=df.index)
        return SignalResult(
            fired=empty_series,
            strength=pd.Series([0.0] * len(df), index=df.index),
            explanation=empty_explanations
        )
    
    high_52w, low_52w = calculate_52w_high_low(df['high'], df['low'])
    
    # Position within 52w range (0 = 52w low, 1 = 52w high)
    range_position = (df['close'] - low_52w) / (high_52w - low_52w + 1e-8)
    range_position = range_position.clip(0, 1)
    
    # Signal strength based on position
    signal_strength = np.where(
        range_position > 0.8,
        0.2,  # Near 52w high (positive)
        np.where(
            range_position < 0.2,
            -0.1,  # Near 52w low (negative)
            0.0   # Middle range
        )
    )
    
    fired = signal_strength != 0
    
    # Explanations with distance context
    explanations = pd.Series([
        f"Near 52w HIGH (top {pos:.0%} of range)" if pos > 0.8
        else f"Near 52w LOW (bottom {pos:.0%} of range)" if pos < 0.2
        else ""
        for pos in range_position
    ], index=df.index)
    
    return SignalResult(
        fired=pd.Series(fired, index=df.index),
        strength=pd.Series(signal_strength, index=df.index),
        explanation=explanations
    )
