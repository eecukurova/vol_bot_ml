"""
Signal result types for v1.1.
"""

from dataclasses import dataclass
import pandas as pd


@dataclass
class SignalResult:
    """
    Result from signal detection.
    
    Attributes:
        fired: Boolean Series indicating when signal fired
        strength: Float Series (0-1) indicating signal strength
        explanation: String Series with human-readable explanations
    """
    fired: pd.Series
    strength: pd.Series
    explanation: pd.Series
    
    def __post_init__(self):
        """Validate signal result."""
        if len(self.fired) != len(self.strength) or len(self.fired) != len(self.explanation):
            raise ValueError("All series must have the same length")

