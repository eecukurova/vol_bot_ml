"""
Signal generation modules (v1.1).
"""

from .types import SignalResult
from .ema_trend import detect_ema_trend
from .rsi_rebound import detect_rsi_rebound
from .volume_spike import detect_volume_spike
from .donchian_breakout import detect_donchian_breakout
from .hi52_setup import detect_52w_setup

__all__ = [
    "SignalResult",
    "detect_ema_trend",
    "detect_rsi_rebound",
    "detect_volume_spike",
    "detect_donchian_breakout",
    "detect_52w_setup"
]

