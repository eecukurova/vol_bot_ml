"""
Configuration management using Pydantic v1.1 - Enhanced with hardening & analytics.
"""

import os
from pathlib import Path
from typing import Literal, Dict
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load .env file
load_dotenv()


class ScoringWeights(BaseModel):
    """Scoring weight configuration."""
    technical: float = Field(0.6, ge=0.0, le=1.0)
    momentum: float = Field(0.2, ge=0.0, le=1.0)
    volume: float = Field(0.2, ge=0.0, le=1.0)
    
    def validate(self):
        """Validate that weights sum to 1.0"""
        total = self.technical + self.momentum + self.volume
        if abs(total - 1.0) > 0.01:
            raise ValueError(f"Weights must sum to 1.0, got {total}")
        return self


class DataConfig(BaseModel):
    """Data fetching configuration."""
    min_bars: int = 120
    fetch_workers: int = 4


class RiskConfig(BaseModel):
    """Risk management configuration."""
    free_rate: float = 0.0  # Risk-free rate for Sharpe calculation


class BacktestConfig(BaseModel):
    """Backtest simulation configuration."""
    slippage_bps: int = 5  # 0.05%
    commission_bps: int = 5  # 0.05%
    position_sizing: Literal["fixed_cash", "fixed_pct"] = "fixed_cash"
    fixed_cash_usd: float = 100.0
    fixed_pct: float = 1.0  # % of equity


class ScreenConfig(BaseModel):
    """Screening configuration."""
    include_explanations: bool = True
    max_age_days: int = 10  # Signal freshness filter


class SignalConfig(BaseModel):
    """Individual signal enable flags."""
    ema_trend: bool = True
    rsi_rebound: bool = True
    volume_spike: bool = True
    donchian_breakout: bool = True
    hi52_setup: bool = True


class ExportConfig(BaseModel):
    """Export configuration."""
    include_metrics_json: bool = True


class StorageConfig(BaseModel):
    """Storage configuration for v1.2."""
    root: str = "storage"
    signals_path: str = "storage/signals.parquet"
    orders_path: str = "storage/orders.parquet"
    trades_path: str = "storage/trades.parquet"
    positions_path: str = "storage/positions.json"
    equity_path: str = "storage/equity.csv"
    datasets_dir: str = "storage/datasets"
    rotation_max_mb: int = 256
    rotation_keep: int = 3


class AppConfig(BaseModel):
    """App configuration for v1.2."""
    data_min_bars: int = 120
    fetch_workers: int = 4


class Config(BaseModel):
    """Main application configuration v1.1."""
    
    # Data source
    data_source: Literal["yfinance", "finnhub"] = os.getenv("DATA_SOURCE", "yfinance")
    finnhub_api_key: str = os.getenv("FINNHUB_API_KEY", "")
    
    # Telegram
    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")
    
    # Paths
    project_root: Path = Path(__file__).parent.parent.parent
    data_dir: Path = Field(default_factory=lambda: Path(__file__).parent / "data")
    output_dir: Path = Field(default_factory=lambda: Path("outputs"))
    cache_dir: Path = Field(default_factory=lambda: Path("cache"))
    logs_dir: Path = Field(default_factory=lambda: Path("logs"))
    
    # Scoring
    weights: ScoringWeights = Field(default_factory=ScoringWeights)
    
    # v1.1: New config sections
    data: DataConfig = Field(default_factory=DataConfig)
    risk: RiskConfig = Field(default_factory=RiskConfig)
    bt: BacktestConfig = Field(default_factory=BacktestConfig)
    screen: ScreenConfig = Field(default_factory=ScreenConfig)
    signals_config: SignalConfig = Field(default_factory=SignalConfig)
    export: ExportConfig = Field(default_factory=ExportConfig)
    
    # v1.2: Storage configuration
    storage: StorageConfig = Field(default_factory=StorageConfig)
    app: AppConfig = Field(default_factory=AppConfig)
    
    # Signals (feature flags - deprecated, use signals_config)
    use_rsi_rebound: bool = True
    use_donchian_breakout: bool = True
    use_volume_spike: bool = True
    use_52w_setup: bool = True
    
    # Backtest
    backtest_lookback_days: int = Field(int(os.getenv("BACKTEST_LOOKBACK_DAYS", "180")), ge=30)
    backtest_sl_atr_multiplier: float = Field(float(os.getenv("BACKTEST_SL_ATR_MULTIPLIER", "2.0")), ge=0.5)
    
    # Indicators
    ema_short: int = 50
    ema_long: int = 200
    rsi_period: int = 14
    atr_period: int = 14
    donchian_period: int = 20
    volume_ma_period: int = 20
    
    # Filters
    min_score: float = 50.0
    top_n: int = 25
    
    # Notification
    notify_telegram: bool = Field(default_factory=lambda: bool(os.getenv("TELEGRAM_BOT_TOKEN", "")))
    
    class Config:
        """Pydantic config."""
        arbitrary_types_allowed = True
        
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Create directories
        self.output_dir.mkdir(exist_ok=True)
        self.cache_dir.mkdir(exist_ok=True)
        self.logs_dir.mkdir(exist_ok=True)
        Path(self.storage.root).mkdir(exist_ok=True)
        Path(self.storage.datasets_dir).mkdir(exist_ok=True, parents=True)


# Global config instance
config = Config()

