"""
Core technical indicators.
"""

import pandas as pd
import numpy as np


def calculate_ema(data: pd.Series, period: int) -> pd.Series:
    """
    Calculate Exponential Moving Average.
    
    Args:
        data: Price series
        period: EMA period
    
    Returns:
        EMA series
    """
    return data.ewm(span=period, adjust=False).mean()


def calculate_rsi(data: pd.Series, period: int = 14) -> pd.Series:
    """
    Calculate Relative Strength Index.
    
    Args:
        data: Close price series
        period: RSI period
    
    Returns:
        RSI series (0-100)
    """
    delta = data.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi


def calculate_atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    """
    Calculate Average True Range.
    
    Args:
        high: High prices
        low: Low prices
        close: Close prices
        period: ATR period
    
    Returns:
        ATR series
    """
    tr1 = high - low
    tr2 = abs(high - close.shift())
    tr3 = abs(low - close.shift())
    
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.rolling(window=period).mean()
    
    return atr


def calculate_donchian(high: pd.Series, low: pd.Series, period: int = 20) -> tuple[pd.Series, pd.Series, pd.Series]:
    """
    Calculate Donchian Channels.
    
    Args:
        high: High prices
        low: Low prices
        period: Donchian period
    
    Returns:
        Tuple of (upper, middle, lower) bands
    """
    upper = high.rolling(window=period).max()
    lower = low.rolling(window=period).min()
    middle = (upper + lower) / 2
    
    return upper, middle, lower


def calculate_52w_high_low(high: pd.Series, low: pd.Series) -> tuple[pd.Series, pd.Series]:
    """
    Calculate 52-week high and low.
    
    Args:
        high: High prices
        low: Low prices
    
    Returns:
        Tuple of (52w_high, 52w_low)
    """
    high_52w = high.rolling(window=252).max()
    low_52w = low.rolling(window=252).min()
    
    return high_52w, low_52w


def calculate_volume_ma(volume: pd.Series, period: int = 20) -> pd.Series:
    """
    Calculate Volume Moving Average.
    
    Args:
        volume: Volume series
        period: MA period
    
    Returns:
        Volume MA series
    """
    return volume.rolling(window=period).mean()

