"""ML dataset generation (v1.2)."""

from .dataset import build_dataset

__all__ = ["build_dataset"]

