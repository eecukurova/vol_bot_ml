"""Build ML dataset from signals and prices (v1.2.1 with proper forward returns)."""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import List
from loguru import logger
from ..config import config
from ..utils import safe_to_parquet
from ..data_fetcher import load_stock_data


def _fwd_log_return(close: pd.Series, n: int) -> pd.Series:
    """Calculate forward log return (shift n periods ahead)."""
    return np.log(close.shift(-n) / close)


def build_dataset(
    symbols: List[str],
    start: str,
    end: str,
    horizons: List[int] = [5, 10],
    thresholds: List[float] = [0.01, 0.02]
) -> Path:
    """
    Build ML dataset with features and labels (v1.2).
    
    Args:
        symbols: List of symbols
        start: Start date
        end: End date
        horizons: Forward horizons for labels
        thresholds: Return thresholds for labels
    
    Returns:
        Path to dataset file
    """
    logger.info(f"Building ML dataset for {len(symbols)} symbols")
    logger.info(f"Horizons: {horizons}, Thresholds: {thresholds}")
    
    all_features = []
    
    for symbol in symbols:
        try:
            # Fetch OHLCV data
            df = load_stock_data(symbol, start, end)
            
            if df is None or df.empty or len(df) < max(horizons) + 50:
                logger.warning(f"Insufficient data for {symbol}: {len(df) if df is not None else 0} bars")
                continue
            
            # Calculate features from OHLCV
            from ..indicators import calculate_rsi, calculate_ema, calculate_atr, calculate_donchian
            
            rsi = calculate_rsi(df['close'], 14)
            ema50 = calculate_ema(df['close'], 50)
            ema200 = calculate_ema(df['close'], 200)
            atr = calculate_atr(df['high'], df['low'], df['close'], 14)
            donchian_up, _, donchian_down = calculate_donchian(df['high'], df['low'], 20)
            
            # Build feature DataFrame
            feat_df = pd.DataFrame({
                'ts': df.index,
                'symbol': symbol,
                'close': df['close'].values,
                'rsi': rsi.values,
                'ema50': ema50.values,
                'ema200': ema200.values,
                'ema_ratio': (ema50 / ema200).values,
                'atr14': atr.values,
                'atr_pct': (atr / df['close'] * 100).values,
                'donchian_h': donchian_up.values,
                'donchian_l': donchian_down.values,
                'donchian_width': ((donchian_up - donchian_down) / df['close'] * 100).values,
            })
            
            # Calculate forward returns and labels
            for horizon in horizons:
                feat_df[f'fwd_ret_{horizon}d'] = _fwd_log_return(feat_df['close'], horizon)
                
                for threshold in thresholds:
                    col = f'label_{horizon}d@{threshold:.2f}'
                    # Label = 1 if forward return >= threshold, else 0
                    feat_df[col] = (feat_df[f'fwd_ret_{horizon}d'] >= threshold).astype(int)
            
            all_features.append(feat_df)
            logger.info(f"Built features for {symbol}: {len(feat_df)} rows")
            
        except Exception as e:
            logger.error(f"Error processing {symbol}: {e}")
            continue
    
    if not all_features:
        logger.error("No features built")
        return None
    
    # Combine all symbols
    features_df = pd.concat(all_features, ignore_index=True)
    
    # Drop NaN/inf and trim ends (shift(-n) creates NaN)
    max_h = max(horizons)
    features_df = features_df.iloc[:-max_h]
    features_df = features_df.replace([np.inf, -np.inf], np.nan)
    features_df = features_df.dropna()
    
    logger.info(f"Final dataset: {len(features_df)} rows, {len(features_df.columns)} columns")
    logger.info(f"Columns: {list(features_df.columns)[:10]}...")
    
    # Save
    timestamp = datetime.now().strftime("%Y%m%d")
    output_path = Path(config.storage.datasets_dir) / f"volensy_dataset_{timestamp}.parquet"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    features_df.to_parquet(output_path, index=False)
    
    logger.info(f"Dataset saved to {output_path}")
    return output_path

