"""Telegram notification module."""

import requests
from typing import List
from loguru import logger
from ..config import config


def send_telegram_message(message: str) -> bool:
    """
    Send message to Telegram.
    
    Args:
        message: Message text
    
    Returns:
        True if successful, False otherwise
    """
    if not config.telegram_bot_token or not config.telegram_chat_id:
        logger.warning("Telegram credentials not configured")
        return False
    
    url = f"https://api.telegram.org/bot{config.telegram_bot_token}/sendMessage"
    data = {
        'chat_id': config.telegram_chat_id,
        'text': message,
        'parse_mode': 'HTML'
    }
    
    try:
        response = requests.post(url, data=data, timeout=10)
        response.raise_for_status()
        logger.info("Telegram message sent successfully")
        return True
    
    except Exception as e:
        logger.error(f"Failed to send Telegram message: {e}")
        return False


def send_top_stocks(stocks: List[dict], top_n: int = 10) -> bool:
    """
    Send top stocks to Telegram.
    
    Args:
        stocks: List of stock dicts
        top_n: Number of top stocks to send
    
    Returns:
        True if successful
    """
    if not stocks:
        return False
    
    message = "📊 <b>Volensy NASDAQ Top Stocks</b>\n\n"
    
    for i, stock in enumerate(stocks[:top_n], 1):
        message += f"{i}. <b>{stock['symbol']}</b>\n"
        message += f"   Score: {stock['score']:.1f}\n"
        message += f"   Price: ${stock['close']:.2f}\n\n"
    
    return send_telegram_message(message)

