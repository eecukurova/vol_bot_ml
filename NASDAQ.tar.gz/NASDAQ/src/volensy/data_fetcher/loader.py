"""
Loader for symbols list and stock data (v1.1 with parallel fetching & validation).
"""

import pandas as pd
from pathlib import Path
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from loguru import logger
from ..config import config
from ..utils import get_symbols_file, retry_on_error
from .yfinance_client import YFinanceClient


def _validate_and_clean_data(df: pd.DataFrame, symbol: str) -> Optional[pd.DataFrame]:
    """
    Validate and clean OHLCV data.
    
    Args:
        df: Raw OHLCV DataFrame
        symbol: Symbol for logging
    
    Returns:
        Cleaned DataFrame or None if invalid
    """
    if df.empty:
        logger.warning(f"{symbol}: Empty data")
        return None
    
    # Drop duplicates and sort
    df = df.drop_duplicates().sort_index()
    
    # Ensure index is datetime
    if not isinstance(df.index, pd.DatetimeIndex):
        logger.warning(f"{symbol}: Converting index to datetime")
        df.index = pd.to_datetime(df.index)
        df = df.sort_index()
    
    # Check for sufficient data
    if len(df) < config.data.min_bars:
        logger.warning(f"{symbol}: Insufficient data ({len(df)} < {config.data.min_bars})")
        return None
    
    # Check for NaNs in critical columns
    required_cols = ['open', 'high', 'low', 'close', 'volume']
    for col in required_cols:
        if col in df.columns and df[col].isna().any():
            logger.warning(f"{symbol}: NaNs in {col}, filling with forward fill")
            df[col] = df[col].fillna(method='ffill').fillna(method='bfill')
    
    # Validate price logic
    invalid_rows = (df['high'] < df['low']).any() or (df['high'] < df['close']).any() or (df['low'] > df['close']).any()
    if invalid_rows:
        logger.warning(f"{symbol}: Invalid price logic detected, skipping")
        return None
    
    return df


def load_symbols() -> List[str]:
    """
    Load list of NASDAQ symbols from CSV.
    
    Returns:
        List of symbol strings
    """
    symbols_file = get_symbols_file()
    
    if not symbols_file.exists():
        logger.error(f"Symbols file not found: {symbols_file}")
        return []
    
    try:
        df = pd.read_csv(symbols_file)
        symbols = df['symbol'].tolist()
        logger.info(f"Loaded {len(symbols)} symbols from {symbols_file}")
        return symbols
    except Exception as e:
        logger.error(f"Failed to load symbols: {e}")
        return []


@retry_on_error(max_attempts=3)
def load_stock_data(symbol: str, start: str, end: str) -> pd.DataFrame:
    """
    Load OHLCV data for a single symbol (v1.1 with validation).
    
    Args:
        symbol: Stock symbol
        start: Start date (YYYY-MM-DD)
        end: End date (YYYY-MM-DD)
    
    Returns:
        DataFrame with validated OHLCV data
    """
    client = YFinanceClient()
    data = client.fetch_ohlcv(symbol, start, end)
    validated = _validate_and_clean_data(data, symbol)
    return validated if validated is not None else pd.DataFrame()


def _fetch_single_symbol(symbol: str, start: str, end: str) -> tuple[str, Optional[pd.DataFrame]]:
    """
    Fetch data for a single symbol (thread-safe wrapper).
    
    Args:
        symbol: Stock symbol
        start: Start date
        end: End date
    
    Returns:
        Tuple of (symbol, DataFrame or None)
    """
    try:
        data = load_stock_data(symbol, start, end)
        if data.empty:
            return (symbol, None)
        return (symbol, data)
    except Exception as e:
        logger.error(f"Failed to fetch {symbol}: {e}")
        return (symbol, None)


def load_multiple_stocks(symbols: List[str], start: str, end: str) -> Dict[str, pd.DataFrame]:
    """
    Load OHLCV data for multiple symbols (v1.1 with parallel fetching).
    
    Args:
        symbols: List of symbols
        start: Start date
        end: End date
    
    Returns:
        Dict mapping symbol to validated DataFrame
    """
    max_workers = config.data.fetch_workers
    logger.info(f"Fetching {len(symbols)} symbols with {max_workers} workers")
    
    results = {}
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks
        future_to_symbol = {
            executor.submit(_fetch_single_symbol, symbol, start, end): symbol 
            for symbol in symbols
        }
        
        # Collect results as they complete
        for future in as_completed(future_to_symbol):
            symbol = future_to_symbol[future]
            try:
                fetched_symbol, data = future.result()
                if data is not None and not data.empty:
                    results[symbol] = data
                    logger.debug(f"✅ {symbol}: {len(data)} bars")
            except Exception as e:
                logger.error(f"❌ {symbol}: {e}")
    
    logger.info(f"Successfully fetched {len(results)}/{len(symbols)} symbols")
    return results

