"""
yfinance client for fetching NASDAQ stock data.
"""

import yfinance as yf
import pandas as pd
from typing import Optional, List
from datetime import datetime
from loguru import logger
from ..utils import retry_on_error


class YFinanceClient:
    """Client for fetching data from Yahoo Finance."""
    
    @retry_on_error(max_attempts=3)
    def fetch_ohlcv(self, symbol: str, start: str, end: str) -> pd.DataFrame:
        """
        Fetch OHLCV data for a symbol.
        
        Args:
            symbol: Stock symbol
            start: Start date (YYYY-MM-DD)
            end: End date (YYYY-MM-DD)
        
        Returns:
            DataFrame with OHLCV data
        """
        logger.info(f"Fetching {symbol} from {start} to {end}")
        
        ticker = yf.Ticker(symbol)
        data = ticker.history(start=start, end=end)
        
        if data.empty:
            logger.warning(f"No data for {symbol}")
            return pd.DataFrame()
        
        # Rename columns to lowercase
        data.columns = [col.lower().replace(' ', '_') for col in data.columns]
        
        # Rename to standard format
        data = data.rename(columns={
            'open': 'open',
            'high': 'high',
            'low': 'low',
            'close': 'close',
            'volume': 'volume'
        })
        
        # Calculate typical price for indicators
        data['typical_price'] = (data['high'] + data['low'] + data['close']) / 3
        
        logger.info(f"Fetched {len(data)} bars for {symbol}")
        
        return data
    
    def fetch_multiple(self, symbols: List[str], start: str, end: str) -> dict[str, pd.DataFrame]:
        """
        Fetch OHLCV for multiple symbols.
        
        Args:
            symbols: List of symbols
            start: Start date
            end: End date
        
        Returns:
            Dict mapping symbol to DataFrame
        """
        results = {}
        for symbol in symbols:
            try:
                data = self.fetch_ohlcv(symbol, start, end)
                if not data.empty:
                    results[symbol] = data
            except Exception as e:
                logger.error(f"Failed to fetch {symbol}: {e}")
                continue
        
        return results


def latest_close(symbol: str) -> float | None:
    """
    Get latest close price for a symbol (v1.2.1).
    
    Args:
        symbol: Stock symbol
        
    Returns:
        Latest close price or None if not available
    """
    try:
        ticker = yf.Ticker(symbol)
        data = ticker.history(period="5d", interval="1d", progress=False, auto_adjust=True)
        
        if data is None or data.empty:
            logger.warning(f"No recent data for {symbol}")
            return None
        
        # yfinance returns uppercase column names by default
        close_col = 'Close' if 'Close' in data.columns else 'close'
        return float(data[close_col].iloc[-1])
    
    except Exception as e:
        logger.error(f"Failed to fetch latest close for {symbol}: {e}")
        return None

