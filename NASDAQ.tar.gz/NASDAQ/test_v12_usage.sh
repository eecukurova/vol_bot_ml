#!/bin/bash
# Volensy NASDAQ Screener v1.2 - Usage Test Script

set -e

echo "╔════════════════════════════════════════════╗"
echo "║  VOLENSY v1.2 - REAL USAGE TEST             ║"
echo "╚════════════════════════════════════════════╝"
echo ""

cd ~/ATR/NASDAQ

# Step 1: Fetch data (full year for sufficient bars)
echo "📊 Step 1: Fetching data..."
python3 -m src.volensy.cli fetch --start 2024-01-01 --end 2025-01-01
echo "✅ Fetch complete"
echo ""

# Step 2: Screen with signal logging
echo "🔍 Step 2: Screening for candidates..."
python3 -m src.volensy.cli screen --top 15 --include-explanations --export csv,html
echo "✅ Screen complete"
echo ""

# Check if storage/signals.parquet exists
if [ -f "storage/signals.parquet" ]; then
    echo "✅ Signals logged to storage/signals.parquet"
    echo ""
fi

# Step 3: Paper run
echo "📈 Step 3: Running paper trading..."
python3 -m src.volensy.cli run --top 10 --initial-cash 100000
echo "✅ Paper run complete"
echo ""

# Step 4: Check positions
echo "👀 Step 4: Checking positions..."
python3 -m src.volensy.cli positions
echo ""

# Step 5: Build dataset
echo "🤖 Step 5: Building ML dataset..."
python3 -m src.volensy.cli dataset --start 2024-01-01 --end 2025-01-01 --horizons 5,10 --thresholds 0.01,0.02
echo "✅ Dataset complete"
echo ""

# Summary
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📁 Generated Files:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ls -lh storage/*.parquet 2>/dev/null || echo "No parquet files yet"
ls -lh storage/*.json 2>/dev/null || echo "No JSON files yet"  
ls -lh storage/*.csv 2>/dev/null || echo "No CSV files yet"
ls -lh storage/datasets/*.parquet 2>/dev/null || echo "No datasets yet"
echo ""
echo "✅ v1.2 usage test complete!"

