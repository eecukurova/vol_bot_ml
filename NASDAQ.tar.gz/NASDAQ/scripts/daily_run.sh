#!/bin/bash
# Volensy NASDAQ Screener - Daily Automation Script (v1.2.1)
# Usage: ./scripts/daily_run.sh

set -euo pipefail

cd "$(dirname "$0")/.."

echo "╔════════════════════════════════════════════╗"
echo "║  VOLENSY DAILY RUN - $(date +%Y-%m-%d)         ║"
echo "╚════════════════════════════════════════════╝"
echo ""

# Configuration
START_DATE=$(date -v-365d +%Y-%m-%d 2>/dev/null || date -d "365 days ago" +%Y-%m-%d)
END_DATE=$(date +%Y-%m-%d)

echo "📅 Date range: $START_DATE to $END_DATE"
echo ""

# Step 1: Fetch data
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 Step 1: Fetching data..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python3 -m src.volensy.cli fetch --start "$START_DATE" --end "$END_DATE"
if [ $? -eq 0 ]; then
    echo "✅ Fetch complete"
else
    echo "❌ Fetch failed"
    exit 1
fi
echo ""

# Step 2: Screen
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔍 Step 2: Screening candidates..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python3 -m src.volensy.cli screen --top 20 --include-explanations --export csv,html
if [ $? -eq 0 ]; then
    echo "✅ Screen complete"
    echo "📄 Outputs:"
    ls -lh outputs/screen_*.csv 2>/dev/null | tail -1 || true
    ls -lh outputs/screen_*.html 2>/dev/null | tail -1 || true
else
    echo "❌ Screen failed"
    exit 1
fi
echo ""

# Step 3: Paper run
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📈 Step 3: Running paper trading..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python3 -m src.volensy.cli run --top 10 --initial-cash 100000
if [ $? -eq 0 ]; then
    echo "✅ Paper run complete"
    echo "📊 Positions:"
    python3 -m src.volensy.cli positions
else
    echo "❌ Paper run failed"
    exit 1
fi
echo ""

# Step 4: Dataset
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🤖 Step 4: Building ML dataset..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python3 -m src.volensy.cli dataset --start "$START_DATE" --end "$END_DATE" --horizons 5,10 --thresholds 0.01,0.02
if [ $? -eq 0 ]; then
    echo "✅ Dataset complete"
    echo "📁 Dataset:"
    ls -lh storage/datasets/*.parquet 2>/dev/null | tail -1 || true
else
    echo "❌ Dataset failed"
    exit 1
fi
echo ""

# Health Check (v1.2.1)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🏥 Health Check"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python3 scripts/health_check.py
HEALTH_STATUS=$?
echo ""

# Summary
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ DAILY RUN COMPLETE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Storage stats
echo "📊 Storage Statistics:"
if [ -f "storage/signals.parquet" ]; then
    python3 -c "import pandas as pd; df = pd.read_parquet('storage/signals.parquet'); print(f\"  • signals.parquet: {len(df)} rows\")"
fi
if [ -f "storage/equity.csv" ]; then
    python3 -c "import pandas as pd; df = pd.read_csv('storage/equity.csv'); print(f\"  • equity.csv: {len(df)} records\")"
fi
echo ""

# Parquet sizes
echo "📁 Generated files:"
ls -lh outputs/*.csv 2>/dev/null | wc -l | xargs echo "  • CSV files:"
ls -lh storage/*.parquet 2>/dev/null | wc -l | xargs echo "  • Parquet files:"
ls -lh storage/datasets/*.parquet 2>/dev/null | wc -l | xargs echo "  • Dataset files:"
echo ""

# Exit with health status
exit $HEALTH_STATUS

