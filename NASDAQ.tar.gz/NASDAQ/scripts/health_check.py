#!/usr/bin/env python3
"""
Health check script for Volensy NASDAQ Screener (v1.2.1).
Run as: python3 scripts/health_check.py
"""

import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta
import sys

def check_signals():
    """Check signals.parquet health."""
    p = Path("storage/signals.parquet")
    if not p.exists():
        print("⚠️  signals.parquet not found")
        return False
    
    try:
        df = pd.read_parquet(p)
        last_ts_str = df['ts'].max()
        last_ts = pd.to_datetime(last_ts_str)
        
        # Handle timezone-aware comparison
        now = datetime.now()
        if last_ts.tzinfo is not None:
            now = pd.Timestamp.now(tz=last_ts.tz)
        
        age_hours = (now - last_ts).total_seconds() / 3600
        
        print(f"✅ Signals: {len(df)} rows")
        print(f"   Last signal: {last_ts} ({age_hours:.1f}h ago)")
        print(f"   Columns: {list(df.columns)}")
        
        # Check for NaN
        nan_cols = df.isna().sum()
        if nan_cols.sum() > 0:
            print(f"⚠️  NaN columns: {dict(nan_cols[nan_cols > 0])}")
        
        return True
    
    except Exception as e:
        print(f"❌ Error reading signals: {e}")
        return False


def check_equity():
    """Check equity.csv health."""
    p = Path("storage/equity.csv")
    if not p.exists():
        print("⚠️  equity.csv not found")
        return False
    
    try:
        df = pd.read_csv(p)
        last_date = pd.to_datetime(df['timestamp'].iloc[-1])
        age_hours = (datetime.now() - last_date).total_seconds() / 3600
        
        current_equity = df['equity'].iloc[-1]
        max_dd = df['drawdown'].min() if 'drawdown' in df.columns else 0
        
        print(f"✅ Equity: {len(df)} records")
        print(f"   Last update: {last_date} ({age_hours:.1f}h ago)")
        print(f"   Current: ${current_equity:,.2f}")
        print(f"   Max DD: {max_dd:.2f}%")
        
        return True
    
    except Exception as e:
        print(f"❌ Error reading equity: {e}")
        return False


def check_dataset():
    """Check dataset health."""
    datasets_dir = Path("storage/datasets")
    if not datasets_dir.exists():
        print("⚠️  No datasets directory")
        return False
    
    datasets = list(datasets_dir.glob("volensy_dataset_*.parquet"))
    if not datasets:
        print("⚠️  No datasets found")
        return False
    
    latest = max(datasets, key=lambda p: p.stat().st_mtime)
    
    try:
        df = pd.read_parquet(latest)
        
        # Check for NaN/inf
        nan_count = df.isna().sum().sum()
        inf_cols = []
        for col in df.select_dtypes(include=['float64']).columns:
            if (df[col] == float('inf')).any() or (df[col] == float('-inf')).any():
                inf_cols.append(col)
        
        print(f"✅ Dataset: {latest.name}")
        print(f"   Rows: {len(df)}, Columns: {len(df.columns)}")
        print(f"   NaN values: {nan_count}")
        
        if nan_count > 0:
            print(f"⚠️  Dataset has {nan_count} NaN values")
        
        if inf_cols:
            print(f"⚠️  Infinite values in: {inf_cols}")
        
        # File size
        size_mb = latest.stat().st_size / (1024 * 1024)
        print(f"   Size: {size_mb:.2f} MB")
        
        return nan_count == 0 and len(inf_cols) == 0
    
    except Exception as e:
        print(f"❌ Error reading dataset: {e}")
        return False


def check_storage():
    """Check storage disk usage."""
    storage_dir = Path("storage")
    if not storage_dir.exists():
        print("⚠️  storage/ directory not found")
        return False
    
    total_size = sum(f.stat().st_size for f in storage_dir.rglob("*") if f.is_file())
    size_mb = total_size / (1024 * 1024)
    
    print(f"✅ Storage: {size_mb:.2f} MB")
    
    # List top files
    files = [(f, f.stat().st_size) for f in storage_dir.rglob("*") if f.is_file()]
    files.sort(key=lambda x: x[1], reverse=True)
    
    print("   Top files:")
    for f, size in files[:5]:
        print(f"     {f.name}: {size / (1024 * 1024):.2f} MB")
    
    return size_mb < 1024  # Warn if > 1GB


def main():
    """Run all health checks."""
    print("╔════════════════════════════════════════════╗")
    print("║  VOLENSY HEALTH CHECK                      ║")
    print("╚════════════════════════════════════════════╝")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    results = []
    
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("1. Signals Check")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    results.append(check_signals())
    print()
    
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("2. Equity Check")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    results.append(check_equity())
    print()
    
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("3. Dataset Check")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    results.append(check_dataset())
    print()
    
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("4. Storage Check")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    results.append(check_storage())
    print()
    
    # Summary
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    if all(results):
        print("✅ ALL CHECKS PASSED")
        sys.exit(0)
    else:
        print("⚠️  SOME CHECKS FAILED")
        sys.exit(1)


if __name__ == "__main__":
    main()

