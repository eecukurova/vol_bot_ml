# Volensy NASDAQ Screener v1.1 - Enhanced Edition

## 🚀 What's New in v1.1

### Enhanced Configuration
- **6 new config sections**: DataConfig, RiskConfig, BacktestConfig, ScreenConfig, SignalConfig, ExportConfig
- **Parallel data fetching**: Multi-threaded downloads with `fetch_workers` control
- **Data validation**: Automatic cleanup, duplicate removal, NaN handling
- **Signal explanations**: Human-readable descriptions for each signal
- **Age filtering**: Filter stale signals with `max_age_days`
- **Score breakdown**: Detailed component analysis (technical, momentum, volume)

### Enhanced Features
- **Cost simulation**: Slippage and commission in basis points
- **Position sizing**: Fixed cash or percentage-based
- **Enhanced metrics**: Sharpe, Sortino, CAGR, Volatility
- **Conditional formatting**: Color-coded scores in HTML export
- **Tooltips**: Hover explanations in HTML output
- **Universe selection**: Choose between pre-defined or custom lists

---

## 📋 New Configuration Options

### DataConfig
```python
data.min_bars: int = 120      # Minimum bars required
data.fetch_workers: int = 4   # Parallel fetch threads
```

### RiskConfig
```python
risk.free_rate: float = 0.0   # Risk-free rate for Sharpe
```

### BacktestConfig
```python
bt.slippage_bps: int = 5              # 0.05% slippage
bt.commission_bps: int = 5            # 0.05% commission
bt.position_sizing: str = "fixed_cash" # or "fixed_pct"
bt.fixed_cash_usd: float = 100.0
bt.fixed_pct: float = 1.0
```

### ScreenConfig
```python
screen.include_explanations: bool = True
screen.max_age_days: int = 10
```

### SignalConfig
```python
signals_config.ema_trend: bool = True
signals_config.rsi_rebound: bool = True
signals_config.volume_spike: bool = True
signals_config.donchian_breakout: bool = True
signals_config.hi52_setup: bool = True
```

### ExportConfig
```python
export.include_metrics_json: bool = True
```

---

## 🎯 Usage Examples

### Fetch Data
```bash
python -m src.volensy.cli fetch \
  --start 2024-01-01 \
  --end 2025-01-01 \
  --universe "file:src/volensy/data/symbols.csv"
```

### Screen with Explanations
```bash
python -m src.volensy.cli screen \
  --top 20 \
  --include-explanations \
  --export csv,html \
  --universe nasdaq100
```

### Backtest with Custom Costs
```bash
python -m src.volensy.cli backtest \
  --lookback-days 180 \
  --slippage-bps 5 \
  --commission-bps 5 \
  --position-sizing fixed_cash \
  --fixed-cash-usd 100
```

---

## 📊 Output Examples

### CSV Output (v1.1)
```csv
symbol,score,close,technical_score,momentum_score,volume_score,fired_signals,explanations,last_signal_age,score_breakdown
AAPL,92.5,180.50,95,88,92,"['ema_trend','rsi_rebound','volume_spike']","EMA50/200 Bull, RSI rebound >30, Vol spike 1.8x avg",2,"{'technical':95,'momentum':88,'volume':92}"
```

### HTML Output Features
- **Color coding**: Green (≥80), Yellow (40-79), Red (<40)
- **Hover tooltips**: Explanations and score breakdown on hover
- **Summary section**: Total symbols, average score, top signals

### Metrics JSON
```json
{
  "metrics": {
    "CAGR": 0.1250,
    "Volatility": 0.1800,
    "Sharpe": 0.6944,
    "Sortino": 1.2350,
    "MaxDrawdown": -0.0820,
    "WinRate": 0.6200,
    "Expectancy": 0.0045
  },
  "total_trades": 45,
  "config": {
    "slippage_bps": 5,
    "commission_bps": 5,
    "position_sizing": "fixed_cash",
    "fixed_cash_usd": 100.0
  }
}
```

---

## 🔧 Advanced Usage

### Custom Universe
```bash
# Use custom symbol list
python -m src.volensy.cli screen --universe "file:/path/to/custom_symbols.csv"
```

### Disable Explanations
```bash
python -m src.volensy.cli screen --no-include-explanations
```

### Backtest with Percentage Sizing
```bash
python -m src.volensy.cli backtest \
  --position-sizing fixed_pct \
  --fixed-pct 1.5
```

---

## 📈 Signal Details (v1.1)

### EMA Trend
- **Returns**: `SignalResult` with Bull/Bear direction
- **Explanation**: "EMA50/200 Bull" or "EMA50/200 Bear"

### RSI Rebound
- **Returns**: `SignalResult` with strength (0-1)
- **Explanation**: "RSI rebound >30 on 2025-01-15"

### Volume Spike
- **Returns**: `SignalResult` with gradations
- **Explanation**: "Vol spike 1.8x avg"
- **Strength**: 0.5 for 1.5x, 1.0 for 2.0x+

### Donchian Breakout
- **Returns**: `SignalResult` with upper/lower breakout
- **Explanation**: "Donchian 20d upper breakout" or "lower breakout"

### 52-week Setup
- **Returns**: `SignalResult` with distance metrics
- **Explanation**: "Near 52w HIGH (top 85% of range)"

---

## 🧪 Testing

### Quick Test
```bash
# Test data fetching
python -m src.volensy.cli fetch --start 2024-01-01

# Test screening
python -m src.volensy.cli screen --top 10

# Test backtest
python -m src.volensy.cli backtest --lookback-days 90
```

---

## 📝 Migration from v1.0

### Breaking Changes
- Signal modules now return `SignalResult` instead of `pd.Series`
- Screen results include new columns: `fired_signals`, `explanations`, `last_signal_age`, `score_breakdown`
- Backtest requires additional config for costs and sizing

### Upgrading
```bash
# Update dependencies
make install

# Migrate config (optional)
# New config sections are auto-initialized
```

---

## 🐛 Known Issues

- Age filtering may penalize active stocks if signals are recent
- HTML tooltips may overflow on small screens (use full width)
- Parallel fetching may hit API rate limits (adjust `fetch_workers`)

---

## 📚 Documentation

- **v1.0 README**: `README.md`
- **Implementation**: `PROJECT_SETUP_COMPLETE.md`
- **v1.1 Report**: `V1.1_FINAL_REPORT.md`
- **Cursor Prompt**: `CURSOR_MASTER_PROMPT.md`

---

## 🎉 Summary

**v1.1 brings**:
- ✅ Enhanced configuration system
- ✅ Parallel data fetching with validation
- ✅ Signal explanations and breakdowns
- ✅ Cost simulation in backtests
- ✅ Improved export formatting
- ✅ Flexible CLI options

**Ready for production use!** 🚀

