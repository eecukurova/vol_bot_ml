"""
Tests for signals module.
"""

import pytest
from src.volensy.signals import (
    detect_ema_trend,
    detect_rsi_rebound,
    detect_volume_spike,
    detect_donchian_breakout,
    detect_52w_setup
)


def test_detect_ema_trend(sample_ohlcv):
    """Test EMA trend detection."""
    result = detect_ema_trend(sample_ohlcv, 20, 50)
    
    assert len(result) == len(sample_ohlcv)
    assert result.min() >= -1
    assert result.max() <= 1


def test_detect_rsi_rebound(sample_ohlcv):
    """Test RSI rebound detection."""
    result = detect_rsi_rebound(sample_ohlcv)
    
    assert len(result) == len(sample_ohlcv)
    assert result.min() >= 0
    assert result.max() <= 1


def test_detect_volume_spike(sample_ohlcv):
    """Test volume spike detection."""
    result = detect_volume_spike(sample_ohlcv)
    
    assert len(result) == len(sample_ohlcv)
    assert result.min() >= 0
    assert result.max() <= 1


def test_detect_donchian_breakout(sample_ohlcv):
    """Test Donchian breakout detection."""
    result = detect_donchian_breakout(sample_ohlcv)
    
    assert len(result) == len(sample_ohlcv)


def test_detect_52w_setup(sample_ohlcv):
    """Test 52w setup detection."""
    result = detect_52w_setup(sample_ohlcv)
    
    assert len(result) == len(sample_ohlcv)

