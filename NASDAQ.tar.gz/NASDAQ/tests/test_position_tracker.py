"""Tests for position tracker (v1.2)."""

import pytest
from src.volensy.exec.position_tracker import PositionTracker


def test_get_position_empty():
    """Test getting position when none exists."""
    tracker = PositionTracker()
    pos = tracker.get_position("AAPL")
    assert pos is None or pos == {}


def test_apply_trade_buy():
    """Test applying buy trade."""
    tracker = PositionTracker()
    
    # Buy trade
    tracker.apply_trade({
        'symbol': 'AAPL',
        'side': 'BUY',
        'qty': 100,
        'price': 180.0
    })
    
    pos = tracker.get_position('AAPL')
    assert pos['qty'] == 100
    assert pos['avg_price'] == 180.0


def test_apply_trade_sell():
    """Test applying sell trade."""
    tracker = PositionTracker()
    
    # Buy first
    tracker.apply_trade({
        'symbol': 'AAPL',
        'side': 'BUY',
        'qty': 100,
        'price': 180.0
    })
    
    # Sell half
    tracker.apply_trade({
        'symbol': 'AAPL',
        'side': 'SELL',
        'qty': 50,
        'price': 185.0
    })
    
    pos = tracker.get_position('AAPL')
    assert pos['qty'] == 50
    # Avg price should still be 180 (FIFO weighted)


def test_close_all():
    """Test closing all positions."""
    tracker = PositionTracker()
    
    # Add some positions
    tracker.apply_trade({'symbol': 'AAPL', 'side': 'BUY', 'qty': 100, 'price': 180.0})
    tracker.apply_trade({'symbol': 'MSFT', 'side': 'BUY', 'qty': 50, 'price': 300.0})
    
    # Close all
    current_prices = {'AAPL': 185.0, 'MSFT': 305.0}
    close_trades = tracker.close_all(current_prices)
    
    assert len(close_trades) == 2
    assert all(t['side'] == 'SELL' for t in close_trades)
    
    # Positions should be empty
    all_pos = tracker.get_all_positions()
    assert len(all_pos) == 0

