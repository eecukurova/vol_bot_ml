"""Tests for paper broker (v1.2)."""

import pytest
import pandas as pd
from pathlib import Path
from tempfile import TemporaryDirectory
from src.volensy.exec.paper_broker import PaperBroker, Order, Trade


def test_create_order():
    """Test order creation."""
    with TemporaryDirectory() as tmpdir:
        # Mock paths
        import src.volensy.config as config
        config.config.storage.orders_path = str(Path(tmpdir) / "orders.parquet")
        config.config.storage.trades_path = str(Path(tmpdir) / "trades.parquet")
        config.config.bt.slippage_bps = 5
        config.config.bt.commission_bps = 5
        
        broker = PaperBroker()
        order_id = broker.create_order("AAPL", "BUY", 100, 180.0, "test")
        
        assert isinstance(order_id, str)
        assert len(order_id) > 0
        
        # Check files created
        assert Path(tmpdir / "orders.parquet").exists()
        assert Path(tmpdir / "trades.parquet").exists()
        
        # Read back
        orders = broker.get_orders()
        assert len(orders) == 1
        assert orders.iloc[0]['symbol'] == "AAPL"
        assert orders.iloc[0]['side'] == "BUY"


def test_get_trades_empty():
    """Test getting trades when none exist."""
    broker = PaperBroker()
    trades = broker.get_trades()
    assert isinstance(trades, pd.DataFrame)
    assert len(trades) == 0

