"""
Pytest fixtures for tests.
"""

import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta


@pytest.fixture
def sample_ohlcv():
    """Generate sample OHLCV data for testing."""
    dates = pd.date_range(start='2024-01-01', periods=100, freq='D')
    
    # Generate realistic price data
    close = 100 + np.cumsum(np.random.randn(100) * 0.5)
    high = close + np.abs(np.random.randn(100) * 0.5)
    low = close - np.abs(np.random.randn(100) * 0.5)
    open_price = close + np.random.randn(100) * 0.3
    volume = np.random.randint(1000000, 10000000, 100)
    
    df = pd.DataFrame({
        'open': open_price,
        'high': high,
        'low': low,
        'close': close,
        'volume': volume,
        'typical_price': (high + low + close) / 3
    }, index=dates)
    
    return df


@pytest.fixture
def sample_symbols():
    """List of sample symbols."""
    return ['AAPL', 'MSFT', 'NVDA']


@pytest.fixture
def sample_signals():
    """Sample signal data."""
    return {
        'ema_trend': pd.Series([1, 1, -1, 0, 1]),
        'rsi_rebound': pd.Series([0.5, 0.3, 0.8, 0.2, 0.6]),
        'volume_spike': pd.Series([0.2, 0.0, 0.3, 0.1, 0.2])
    }

