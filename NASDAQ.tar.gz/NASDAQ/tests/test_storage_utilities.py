"""Tests for storage utilities (v1.2)."""

import pytest
import pandas as pd
from pathlib import Path
from src.volensy.utils import (
    ensure_dirs,
    rotate_if_big,
    safe_to_parquet,
    safe_append_parquet,
    safe_write_json,
    safe_read_json
)


def test_ensure_dirs(tmp_path):
    """Test directory creation."""
    test_dir = tmp_path / "test_sub" / "test_sub2"
    ensure_dirs(str(test_dir))
    assert test_dir.exists()
    assert test_dir.is_dir()


def test_safe_write_read_json(tmp_path):
    """Test safe JSON write/read."""
    test_file = tmp_path / "test.json"
    test_data = {"key": "value", "number": 42}
    
    safe_write_json(test_data, str(test_file))
    assert test_file.exists()
    
    read_data = safe_read_json(str(test_file))
    assert read_data == test_data
    
    # Test with default
    missing_data = safe_read_json(str(tmp_path / "missing.json"), {"default": True})
    assert missing_data == {"default": True}


def test_safe_to_parquet(tmp_path):
    """Test safe parquet write."""
    test_file = tmp_path / "test.parquet"
    df = pd.DataFrame({"col1": [1, 2, 3], "col2": [4, 5, 6]})
    
    safe_to_parquet(df, str(test_file), append=False)
    assert test_file.exists()
    
    # Read back
    read_df = pd.read_parquet(test_file)
    assert len(read_df) == 3


def test_safe_append_parquet(tmp_path):
    """Test safe append to parquet."""
    test_file = tmp_path / "test.parquet"
    df1 = pd.DataFrame({"col1": [1, 2], "col2": [3, 4]})
    df2 = pd.DataFrame({"col1": [5, 6], "col2": [7, 8]})
    
    # Write first
    safe_to_parquet(df1, str(test_file), append=False)
    
    # Append second
    safe_append_parquet(df2, str(test_file))
    
    # Read back
    read_df = pd.read_parquet(test_file)
    assert len(read_df) == 4  # Both DataFrames combined


def test_rotate_if_big(tmp_path):
    """Test file rotation."""
    test_file = tmp_path / "test.parquet"
    
    # Create large file (simulate)
    large_df = pd.DataFrame({"col1": list(range(10000))})
    large_df.to_parquet(test_file)
    
    # Should not rotate if under limit (default 256MB)
    rotate_if_big(str(test_file), max_mb=256, keep=3)
    assert test_file.exists()  # Still exists (not rotated)

