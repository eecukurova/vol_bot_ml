"""Tests for equity curve (v1.2)."""

import pytest
import pandas as pd
from pathlib import Path
from src.volensy.exec.equity_curve import EquityCurve


def test_equity_curve_init():
    """Test equity curve initialization."""
    curve = EquityCurve(initial_cash=100_000)
    
    assert curve.initial_cash == 100_000
    assert curve.cash == 100_000
    assert len(curve.curve) == 0


def test_update_equity():
    """Test updating equity."""
    curve = EquityCurve(initial_cash=100_000)
    
    prices = {'AAPL': 180.0, 'MSFT': 300.0}
    cash = 90_000
    
    curve.update(prices, cash)
    
    assert len(curve.curve) == 1
    assert curve.curve[0]['cash'] == cash
    assert curve.curve[0]['equity'] >= cash


def test_get_last_equity():
    """Test getting last equity."""
    curve = EquityCurve(initial_cash=100_000)
    
    # Before any update
    assert curve.get_last_equity() == 100_000
    
    # After update
    curve.update({'AAPL': 180.0}, 95_000)
    assert curve.get_last_equity() >= 95_000


def test_save():
    """Test saving equity curve."""
    curve = EquityCurve(initial_cash=100_000)
    curve.update({'AAPL': 180.0}, 95_000)
    
    # Save
    curve.save()
    
    # Check file exists
    assert Path(curve.equity_path).exists()
    
    # Read back
    df = pd.read_csv(curve.equity_path)
    assert len(df) == 1
    assert 'equity' in df.columns
    assert 'cash' in df.columns

