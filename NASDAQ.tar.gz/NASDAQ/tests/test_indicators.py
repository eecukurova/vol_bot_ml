"""
Tests for indicators module.
"""

import pytest
from src.volensy.indicators import (
    calculate_ema,
    calculate_rsi,
    calculate_atr,
    calculate_donchian,
    calculate_52w_high_low,
    calculate_volume_ma
)


def test_calculate_ema(sample_ohlcv):
    """Test EMA calculation."""
    result = calculate_ema(sample_ohlcv['close'], 20)
    
    assert len(result) == len(sample_ohlcv)
    assert not result.isna().all()  # Should have some non-NaN values


def test_calculate_rsi(sample_ohlcv):
    """Test RSI calculation."""
    result = calculate_rsi(sample_ohlcv['close'], 14)
    
    assert len(result) == len(sample_ohlcv)
    assert result.min() >= 0
    assert result.max() <= 100


def test_calculate_atr(sample_ohlcv):
    """Test ATR calculation."""
    result = calculate_atr(
        sample_ohlcv['high'],
        sample_ohlcv['low'],
        sample_ohlcv['close'],
        14
    )
    
    assert len(result) == len(sample_ohlcv)
    assert result.min() >= 0


def test_calculate_donchian(sample_ohlcv):
    """Test Donchian calculation."""
    upper, middle, lower = calculate_donchian(
        sample_ohlcv['high'],
        sample_ohlcv['low'],
        20
    )
    
    assert len(upper) == len(sample_ohlcv)
    assert len(middle) == len(sample_ohlcv)
    assert len(lower) == len(sample_ohlcv)
    assert (upper >= lower).all()


def test_calculate_52w_high_low(sample_ohlcv):
    """Test 52w high/low calculation."""
    high_52w, low_52w = calculate_52w_high_low(
        sample_ohlcv['high'],
        sample_ohlcv['low']
    )
    
    assert len(high_52w) == len(sample_ohlcv)
    assert len(low_52w) == len(sample_ohlcv)
    assert (high_52w >= low_52w).all()


def test_calculate_volume_ma(sample_ohlcv):
    """Test volume MA calculation."""
    result = calculate_volume_ma(sample_ohlcv['volume'], 20)
    
    assert len(result) == len(sample_ohlcv)

