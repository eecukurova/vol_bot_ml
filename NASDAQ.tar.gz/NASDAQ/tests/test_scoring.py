"""
Tests for scoring module.
"""

import pytest
from src.volensy.scoring import ScoreEngine, normalize_score, calculate_composite_score


def test_normalize_score():
    """Test score normalization."""
    # Test basic normalization
    result = normalize_score(0.5, 0, 1)
    assert result == 0.5
    
    # Test clamping
    result = normalize_score(1.5, 0, 1)
    assert result == 1.0
    
    result = normalize_score(-0.5, 0, 1)
    assert result == 0.0


def test_calculate_composite_score():
    """Test composite score calculation."""
    signal_scores = {
        'signal1': 0.5,
        'signal2': 0.3,
        'signal3': 0.8
    }
    
    weights = {
        'signal1': 0.5,
        'signal2': 0.3,
        'signal3': 0.2
    }
    
    result = calculate_composite_score(signal_scores, weights)
    
    assert 0 <= result <= 100


def test_score_engine(sample_signals):
    """Test ScoreEngine."""
    engine = ScoreEngine()
    result = engine.calculate_score(sample_signals)
    
    assert len(result) == 5  # Length of sample signals
    assert result.min() >= 0
    assert result.max() <= 100


def test_explain_score(sample_signals):
    """Test score explanation."""
    engine = ScoreEngine()
    breakdown = engine.explain_score(sample_signals, 0)
    
    assert isinstance(breakdown, dict)
    assert 'ema_trend' in breakdown

